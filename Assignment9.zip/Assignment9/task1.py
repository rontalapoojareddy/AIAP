from typing import Iterable, Tuple


def sum_even_odd(numbers: Iterable[int]) -> Tuple[int, int]:
	"""Compute the sum of even and odd integers in a sequence.

	Args:
		numbers: An iterable of integers to analyze.

	Returns:
		A tuple of two integers `(even_sum, odd_sum)` where:
		- `even_sum` is the sum of all even numbers in `numbers`.
		- `odd_sum` is the sum of all odd numbers in `numbers`.

	Raises:
		TypeError: If any element in `numbers` is not an integer.

	Examples:
		>>> sum_even_odd([1, 2, 3, 4])
		(6, 4)
		>>> sum_even_odd([])
		(0, 0)
	"""
	even_sum = 0
	odd_sum = 0
	for value in numbers:
		if not isinstance(value, int):
			raise TypeError("All elements must be integers.")
		if value % 2 == 0:
			even_sum += value
		else:
			odd_sum += value
	return even_sum, odd_sum


# AI-generated docstring (using an assistant) describing the same function in Google style.
ai_generated_docstring = """Compute sums of even and odd values from a collection of integers.

Args:
	numbers: Iterable of integers whose parity sums will be computed.

Returns:
	A tuple (even_sum, odd_sum) where even_sum is the total of even integers
	and odd_sum is the total of odd integers.

Notes:
	Non-integer elements are not supported and will result in a TypeError.
"""


if __name__ == "__main__":
	try:
		raw = input("Enter integers separated by spaces: ").strip()
		if not raw:
			print("(even_sum, odd_sum) = (0, 0)")
		else:
			parts = raw.split()
			values = [int(p) for p in parts]
			even_sum, odd_sum = sum_even_odd(values)
			print(f"(even_sum, odd_sum) = ({even_sum}, {odd_sum})")
	except ValueError:
		print("Invalid input. Please enter only integers separated by spaces.")

