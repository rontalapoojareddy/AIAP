def print_numbers():
    """Print the first 10 natural numbers."""
    for i in range(1, 11):
        print(i)


if __name__ == "__main__":
    print_numbers()
