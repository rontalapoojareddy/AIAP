def check_number(num):
    """Return a message describing whether num is positive, negative, or zero."""
    if num > 0:
        return "The number is positive"
    if num < 0:
        return "The number is negative"
    return "The number is zero"


if __name__ == "__main__":
    for value in (-5, 0, 7):
        print(f"Input: {value} -> Output: {check_number(value)}")
