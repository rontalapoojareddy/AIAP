function printNumbers() {
  // Print the first 10 natural numbers.
  for (let i = 1; i <= 10; i += 1) {
    console.log(i);
  }
}

// Invoke the function
printNumbers();

