public class task2 {
    // Check if the number is positive, negative, or zero and return a message.
    public static String checkNumber(int num) {
        if (num > 0) {
            return "The number is positive";
        } else if (num < 0) {
            return "The number is negative";
        } else {
            return "The number is zero";
        }
    }

    public static void main(String[] args) {
        int[] values = {-5, 0, 7};
        for (int value : values) {
            System.out.println("Input: " + value + " -> Output: " + checkNumber(value));
        }
    }
}

