#include <iostream>

int factorial(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

int main() {
    int values[] = {5, 0};
    for (int value : values) {
        std::cout << "Input: " << value
                  << " -> Output: Factorial = " << factorial(value)
                  << std::endl;
    }
    return 0;
}

