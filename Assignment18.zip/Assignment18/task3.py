def factorial(n: int) -> int:
    """Compute factorial recursively."""
    if n <= 1:
        return 1
    return n * factorial(n - 1)


if __name__ == "__main__":
    for value in (5, 0):
        print(f"Input: {value} -> Output: Factorial = {factorial(value)}")
