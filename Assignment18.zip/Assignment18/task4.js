function printStudents(students) {
  console.log("Student List:");
  students.forEach((name) => console.log(name));
}

const sampleStudents = ["Alice", "Bob", "Charlie"];
printStudents(sampleStudents);

