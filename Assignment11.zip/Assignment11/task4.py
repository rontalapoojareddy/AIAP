class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, value):
        if not self.root:
            self.root = BSTNode(value)
            return
        self._insert_recursive(self.root, value)

    def _insert_recursive(self, node, value):
        if value < node.value:
            if node.left is None:
                node.left = BSTNode(value)
            else:
                self._insert_recursive(node.left, value)
        else:
            if node.right is None:
                node.right = BSTNode(value)
            else:
                self._insert_recursive(node.right, value)

    def inorder_traversal(self):
        elements = []
        self._inorder(self.root, elements)
        return elements

    def _inorder(self, node, elements):
        if node is None:
            return
        self._inorder(node.left, elements)
        elements.append(node.value)
        self._inorder(node.right, elements)


if __name__ == "__main__":
    bst = BinarySearchTree()
    values_to_insert = [50, 30, 70, 20, 40, 60, 80]
    for value in values_to_insert:
        bst.insert(value)

    print("Inorder traversal:", bst.inorder_traversal())

