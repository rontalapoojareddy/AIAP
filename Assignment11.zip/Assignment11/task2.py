class Queue:
    def __init__(self):
        self._items = []

    def enqueue(self, item):
        self._items.append(item)

    def dequeue(self):
        if self.is_empty():
            raise IndexError("dequeue from empty queue")
        return self._items.pop(0)

    def is_empty(self):
        return len(self._items) == 0


if __name__ == "__main__":
    queue = Queue()
    print("Queue is empty?", queue.is_empty())

    queue.enqueue("task1")
    queue.enqueue("task2")
    queue.enqueue("task3")

    print("Queue is empty?", queue.is_empty())
    print("Dequeue:", queue.dequeue())
    print("Dequeue:", queue.dequeue())
    print("Dequeue:", queue.dequeue())

    print("Queue is empty?", queue.is_empty())

