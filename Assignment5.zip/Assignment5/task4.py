"""Job Applicant Scoring System.

A fair and transparent scoring system for job applicants based on measurable skills 
and experience. The system avoids using protected characteristics and focuses on 
job-relevant qualifications.

Features considered:
- Years of relevant experience
- Education level
- Technical skills match
- Past performance metrics
- Project completion rate
"""

from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum


class EducationLevel(Enum):
    """Education levels with corresponding base points."""
    HIGH_SCHOOL = 1
    ASSOCIATES = 2
    BACHELORS = 3
    MASTERS = 4
    PHD = 5
    
    def get_points(self) -> int:
        """Convert education level to points, allowing for multiple paths to success."""
        return self.value * 5


@dataclass
class JobRequirements:
    """Required and preferred skills/experience for the position."""
    required_skills: List[str]
    preferred_skills: List[str]
    min_years_experience: float
    preferred_years_experience: float
    min_education: EducationLevel


@dataclass
class Applicant:
    """Applicant's relevant qualifications and experience.
    
    Note: Deliberately excludes protected characteristics (age, gender, race, etc.)
    to prevent bias in scoring.
    """
    years_experience: float
    education: EducationLevel
    skills: List[str]
    past_performance_score: Optional[float] = None  # 0-100 if available
    project_completion_rate: Optional[float] = None  # 0-100 if available


def calculate_skill_match_score(
    applicant_skills: List[str],
    required_skills: List[str],
    preferred_skills: List[str]
) -> float:
    """Calculate skill match score (0-100).
    
    Args:
        applicant_skills: List of applicant's skills (case-insensitive)
        required_skills: Must-have skills for the job
        preferred_skills: Nice-to-have skills
        
    Returns:
        float: Score from 0-100 based on matches
    """
    # Normalize skills to lowercase for comparison
    applicant_skills_lower = [s.lower() for s in applicant_skills]
    required_lower = [s.lower() for s in required_skills]
    preferred_lower = [s.lower() for s in preferred_skills]
    
    # Calculate required skills match (crucial)
    if not required_lower:  # Avoid division by zero
        required_score = 100
    else:
        matches = sum(1 for skill in required_lower if skill in applicant_skills_lower)
        required_score = (matches / len(required_lower)) * 100
    
    # Calculate preferred skills match (bonus)
    if not preferred_lower:  # Avoid division by zero
        preferred_score = 0
    else:
        matches = sum(1 for skill in preferred_lower if skill in applicant_skills_lower)
        preferred_score = (matches / len(preferred_lower)) * 20  # Max 20 bonus points
    
    return min(100, required_score + preferred_score)


def score_applicant(applicant: Applicant, requirements: JobRequirements) -> Dict[str, float]:
    """Score an applicant against job requirements. Returns component and total scores.
    
    The scoring system is transparent and based on measurable criteria:
    - Experience: 0-30 points
    - Education: 0-25 points
    - Skills match: 0-30 points
    - Past performance: 0-15 points
    
    Args:
        applicant: The applicant's qualifications
        requirements: The job requirements
        
    Returns:
        Dict with component scores and total score (0-100)
    """
    scores = {}
    
    # Experience score (0-30 points)
    if applicant.years_experience < requirements.min_years_experience:
        scores['experience'] = 0
    else:
        base = 20  # Base points for meeting minimum
        extra = min(10, (applicant.years_experience - requirements.min_years_experience) * 2)
        scores['experience'] = base + extra
    
    # Education score (0-25 points)
    if applicant.education.value < requirements.min_education.value:
        scores['education'] = 0
    else:
        scores['education'] = min(25, applicant.education.get_points())
    
    # Skills match score (0-30 points)
    skill_score = calculate_skill_match_score(
        applicant.skills,
        requirements.required_skills,
        requirements.preferred_skills
    )
    scores['skills'] = (skill_score / 100) * 30
    
    # Past performance score (0-15 points)
    if applicant.past_performance_score is not None:
        scores['past_performance'] = (applicant.past_performance_score / 100) * 10
        if applicant.project_completion_rate is not None:
            scores['past_performance'] += (applicant.project_completion_rate / 100) * 5
    else:
        scores['past_performance'] = 0
    
    # Calculate total (0-100)
    scores['total'] = sum(
        scores[k] for k in ['experience', 'education', 'skills', 'past_performance']
    )
    
    return scores


def main():
    """Demo the scoring system with example applicants."""
    # Example job requirements for a Data Analyst position
    job = JobRequirements(
        required_skills=['python', 'sql', 'data analysis'],
        preferred_skills=['machine learning', 'tableau', 'cloud platforms'],
        min_years_experience=2,
        preferred_years_experience=4,
        min_education=EducationLevel.BACHELORS
    )
    
    # Example applicants with different qualification combinations
    applicants = [
        Applicant(  # Strong candidate with all required skills
            years_experience=3,
            education=EducationLevel.BACHELORS,
            skills=['python', 'sql', 'data analysis', 'tableau'],
            past_performance_score=85,
            project_completion_rate=90
        ),
        Applicant(  # Experienced candidate with advanced degree
            years_experience=5,
            education=EducationLevel.MASTERS,
            skills=['python', 'r', 'machine learning', 'cloud platforms'],
            past_performance_score=95,
            project_completion_rate=95
        ),
        Applicant(  # Entry-level candidate
            years_experience=1,
            education=EducationLevel.BACHELORS,
            skills=['python', 'sql', 'tableau'],
            past_performance_score=None,
            project_completion_rate=None
        )
    ]
    
    # Score and display results
    print("Job Applicant Scoring Demo")
    print("-" * 50)
    print(f"Required skills: {', '.join(job.required_skills)}")
    print(f"Preferred skills: {', '.join(job.preferred_skills)}")
    print(f"Minimum experience: {job.min_years_experience} years")
    print(f"Minimum education: {job.min_education.name}")
    print("\nApplicant Scores:")
    
    for i, applicant in enumerate(applicants, 1):
        scores = score_applicant(applicant, job)
        print(f"\nApplicant {i}:")
        print(f"Experience ({applicant.years_experience} years): {scores['experience']:.1f}/30")
        print(f"Education ({applicant.education.name}): {scores['education']:.1f}/25")
        print(f"Skills: {scores['skills']:.1f}/30")
        print(f"Past Performance: {scores['past_performance']:.1f}/15")
        print(f"Total Score: {scores['total']:.1f}/100")


if __name__ == "__main__":
    main()
