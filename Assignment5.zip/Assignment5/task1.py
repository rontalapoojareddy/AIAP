"""Single-file secure login system (PBKDF2 + asterisk-masked password input).

This file provides:
- atomic JSON-backed user store (`users.json` next to this file)
- password hashing with PBKDF2-HMAC-SHA256
- secure comparison with hmac.compare_digest
- registration and login CLI
- a cross-platform password input routine that shows '*' as you type (on Windows it uses msvcrt;
  on POSIX it uses termios/tty). If masked input is not supported, it falls back to getpass.

No hardcoded credentials are used.
"""

import os
import json
import sys
import hmac
import hashlib
import secrets
from typing import Dict, Any

try:
	# getpass is fallback if low-level terminal read isn't available
	from getpass import getpass
except Exception:
	def getpass(prompt="Password: "):
		return input(prompt)

_HERE = os.path.dirname(__file__)
USERS_FILE = os.path.join(_HERE, "users.json")
DEFAULT_ITERATIONS = 200_000


def _ensure_users_file():
	if not os.path.exists(USERS_FILE):
		with open(USERS_FILE, "w", encoding="utf-8") as f:
			json.dump({}, f)


def load_users() -> Dict[str, Any]:
	_ensure_users_file()
	with open(USERS_FILE, "r", encoding="utf-8") as f:
		try:
			return json.load(f)
		except json.JSONDecodeError:
			return {}


def save_users(users: Dict[str, Any]) -> None:
	tmp = USERS_FILE + ".tmp"
	with open(tmp, "w", encoding="utf-8") as f:
		json.dump(users, f, indent=2)
	os.replace(tmp, USERS_FILE)


def hash_password(password: str, salt_hex: str = None, iterations: int = DEFAULT_ITERATIONS) -> Dict[str, Any]:
	if salt_hex is None:
		salt = secrets.token_bytes(16)
		salt_hex = salt.hex()
	else:
		salt = bytes.fromhex(salt_hex)
	dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
	return {"salt": salt_hex, "hash": dk.hex(), "iterations": iterations}


def verify_password(password: str, salt_hex: str, hash_hex: str, iterations: int = DEFAULT_ITERATIONS) -> bool:
	salt = bytes.fromhex(salt_hex)
	dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
	return hmac.compare_digest(dk.hex(), hash_hex)


def register_user(username: str, password: str) -> bool:
	if not username or not password:
		return False
	if len(password) < 8:
		return False
	users = load_users()
	if username in users:
		return False
	users[username] = hash_password(password)
	save_users(users)
	return True


def authenticate_user(username: str, password: str) -> bool:
	users = load_users()
	cred = users.get(username)
	if not cred:
		return False
	try:
		return verify_password(password, cred["salt"], cred["hash"], cred.get("iterations", DEFAULT_ITERATIONS))
	except Exception:
		return False


def _get_password_visible(prompt: str = "Password: ") -> str:
	"""Return visible password input (echoed). Uses plain input so characters are shown.

	Note: Showing passwords is insecure; this implements the user's request to display
	the password as it's typed.
	"""
	try:
		return input(prompt)
	except EOFError:
		return ""


def main():
	print("Secure single-file login demo")
	while True:
		print("\nOptions: [r]egister  [l]ogin  [q]uit")
		choice = input("Choose an option: ").strip().lower()
		if choice in ("q", "quit"):
			print("Goodbye")
			break
		if choice in ("r", "register"):
			username = input("Choose a username: ").strip()
			try:
				password = _get_password_visible("Choose a password: ")
				confirm = _get_password_visible("Confirm password: ")
			except KeyboardInterrupt:
				print("\nOperation cancelled")
				continue
			if password != confirm:
				print("Passwords do not match.")
				continue
			if register_user(username, password):
				print("User registered.")
			else:
				print("Registration failed (user may exist or password too weak).")
			continue
		if choice in ("l", "login"):
			username = input("Username: ").strip()
			try:
				password = _get_password_visible("Password: ")
			except KeyboardInterrupt:
				print("\nOperation cancelled")
				continue
			if authenticate_user(username, password):
				print(f"Welcome, {username}!")
			else:
				print("Invalid username or password.")
			continue
		print("Unknown option")
if __name__ == "__main__":
	main()