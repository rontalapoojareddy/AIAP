"""Simple inclusive greeting system."""

def greet_user(name: str, gender: str = 'neutral') -> str:
    """Create a greeting with optional gender-inclusive titles.
    
    Args:
        name: Person's name
        gender: 'male', 'female', or 'neutral' (default)
    
    Returns:
        Greeting message with appropriate title
    """
    # Simple title mapping
    titles = {
        'male': 'Mr.',
        'female': 'Mrs.',
        'neutral': 'Mx.'
    }
    
    # Get title (default to Mx. if gender not recognized)
    title = titles.get(gender.lower(), 'Mx.')
    
    return f"Hello, {title} {name}! Welcome."


def main():
    """Show example greetings."""
    print("Simple Greeting Examples:")
    print("-" * 20)
    
    # Test different cases
    print(greet_user("Alex"))                    # Default neutral
    print(greet_user("Sam", "neutral"))          # Explicit neutral
    print(greet_user("Jamie", "female"))         # Female
    print(greet_user("Chris", "male"))           # Male
    

if __name__ == "__main__":
    main()
