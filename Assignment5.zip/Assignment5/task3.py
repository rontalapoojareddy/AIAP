"""Recursive Fibonacci Number Calculator.

This module provides a function to calculate the nth Fibonacci number using recursion.
The Fibonacci sequence is defined as:
- F(0) = 0
- F(1) = 1
- F(n) = F(n-1) + F(n-2) for n > 1

Example sequence: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...
"""

def fibonacci(n: int) -> int:
    """Calculate the nth Fibonacci number recursively.
    
    Args:
        n (int): The position in the Fibonacci sequence (0-based indexing).
                 Must be non-negative.
    
    Returns:
        int: The nth Fibonacci number.
    
    Raises:
        ValueError: If n is negative.
    
    Examples:
        >>> fibonacci(0)
        0
        >>> fibonacci(1)
        1
        >>> fibonacci(5)  # 5th number (0-based index)
        5
        >>> fibonacci(7)  # 7th number
        13
    """
    # Input validation: ensure n is non-negative
    if n < 0:
        raise ValueError("Fibonacci index must be non-negative")
    
    # Base cases:
    # F(0) = 0
    if n == 0:
        return 0
    # F(1) = 1
    if n == 1:
        return 1
    
    # Recursive case:
    # F(n) = F(n-1) + F(n-2)
    # This breaks down the problem into smaller subproblems
    return fibonacci(n - 1) + fibonacci(n - 2)


def main():
    """Demonstrate the fibonacci function with example calculations."""
    # Test cases to demonstrate the function
    test_numbers = [0, 1, 2, 3, 4, 5, 6, 7]
    
    print("Fibonacci Sequence Calculator (Recursive Implementation)")
    print("-" * 50)
    
    # Calculate and display Fibonacci numbers
    for n in test_numbers:
        result = fibonacci(n)
        print(f"F({n}) = {result}")
    
    # Show a practical example
    print("\nFor example, F(7) = 13 because:")
    print("F(7) = F(6) + F(5)")
    print("F(6) = F(5) + F(4) = 8")
    print("F(5) = F(4) + F(3) = 5")
    print("And 8 + 5 = 13")


if __name__ == "__main__":
    main()
