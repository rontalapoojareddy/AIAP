def process_scores(scores):
    """
    Original unstructured function that does everything in one place.
    Issues:
    - Multiple responsibilities in one function
    - Repeated iteration over scores
    - No reusability
    - Hard to test individual operations
    - Not modular
    """
    total = 0
    for s in scores:
        total += s
    avg = total / len(scores)
    
    highest = scores[0]
    for s in scores:
        if s > highest:
            highest = s
    
    lowest = scores[0]
    for s in scores:
        if s < lowest:
            lowest = s
    
    print("Average:", avg)
    print("Highest:", highest)
    print("Lowest:", lowest)


# ============================================================================
# MODULARIZED VERSION WITH HELPER FUNCTIONS
# ============================================================================

def calculate_total(scores: list) -> float:
    """
    Calculate the sum of all scores.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Total sum of all scores
    """
    total = 0
    for score in scores:
        total += score
    return total


def calculate_average(scores: list) -> float:
    """
    Calculate the average of all scores.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Average of all scores
    
    Raises:
        ValueError: If scores list is empty
    """
    if not scores:
        raise ValueError("Cannot calculate average of empty list")
    
    total = calculate_total(scores)
    return total / len(scores)


def find_highest(scores: list) -> float:
    """
    Find the highest score in the list.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Highest score
    
    Raises:
        ValueError: If scores list is empty
    """
    if not scores:
        raise ValueError("Cannot find highest in empty list")
    
    highest = scores[0]
    for score in scores:
        if score > highest:
            highest = score
    return highest


def find_lowest(scores: list) -> float:
    """
    Find the lowest score in the list.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Lowest score
    
    Raises:
        ValueError: If scores list is empty
    """
    if not scores:
        raise ValueError("Cannot find lowest in empty list")
    
    lowest = scores[0]
    for score in scores:
        if score < lowest:
            lowest = score
    return lowest


def print_statistics(average: float, highest: float, lowest: float) -> None:
    """
    Print score statistics to the console.
    
    Args:
        average: Average score
        highest: Highest score
        lowest: Lowest score
    """
    print(f"Average: {average:.2f}")
    print(f"Highest: {highest}")
    print(f"Lowest: {lowest}")


def process_scores_modularized(scores: list) -> dict:
    """
    Modularized version that processes scores using helper functions.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Dictionary containing statistics (average, highest, lowest, total)
    
    Raises:
        ValueError: If scores list is empty
    """
    if not scores:
        raise ValueError("Cannot process empty scores list")
    
    average = calculate_average(scores)
    highest = find_highest(scores)
    lowest = find_lowest(scores)
    
    print_statistics(average, highest, lowest)
    
    return {
        'average': average,
        'highest': highest,
        'lowest': lowest,
        'total': calculate_total(scores)
    }


# ============================================================================
# ALTERNATIVE VERSION USING BUILT-IN FUNCTIONS (MOST PYTHONIC)
# ============================================================================

def process_scores_pythonic(scores: list) -> dict:
    """
    Pythonic version using built-in functions for better performance.
    
    Args:
        scores: List of numerical scores
    
    Returns:
        Dictionary containing statistics
    """
    if not scores:
        raise ValueError("Cannot process empty scores list")
    
    average = sum(scores) / len(scores)
    highest = max(scores)
    lowest = min(scores)
    
    print_statistics(average, highest, lowest)
    
    return {
        'average': average,
        'highest': highest,
        'lowest': lowest,
        'total': sum(scores)
    }


# ============================================================================
# EVEN MORE MODULAR - STATISTICS CLASS APPROACH
# ============================================================================

class ScoreStatistics:
    """
    A class to encapsulate score statistics calculations.
    Provides a clean interface for working with score data.
    """
    
    def __init__(self, scores: list):
        """
        Initialize with a list of scores.
        
        Args:
            scores: List of numerical scores
        """
        if not scores:
            raise ValueError("Scores list cannot be empty")
        
        self.scores = scores
        self._total = None
        self._average = None
        self._highest = None
        self._lowest = None
    
    @property
    def total(self) -> float:
        """Calculate and return the total of all scores."""
        if self._total is None:
            self._total = calculate_total(self.scores)
        return self._total
    
    @property
    def average(self) -> float:
        """Calculate and return the average of all scores."""
        if self._average is None:
            self._average = self.total / len(self.scores)
        return self._average
    
    @property
    def highest(self) -> float:
        """Find and return the highest score."""
        if self._highest is None:
            self._highest = find_highest(self.scores)
        return self._highest
    
    @property
    def lowest(self) -> float:
        """Find and return the lowest score."""
        if self._lowest is None:
            self._lowest = find_lowest(self.scores)
        return self._lowest
    
    def display(self) -> None:
        """Display all statistics."""
        print_statistics(self.average, self.highest, self.lowest)
    
    def to_dict(self) -> dict:
        """Return statistics as a dictionary."""
        return {
            'total': self.total,
            'average': self.average,
            'highest': self.highest,
            'lowest': self.lowest
        }


# Example usage
if __name__ == "__main__":
    test_scores = [85, 92, 78, 96, 88, 90, 87]
    
    print("=" * 70)
    print("ORIGINAL VERSION")
    print("=" * 70)
    process_scores(test_scores)
    
    print("\n" + "=" * 70)
    print("MODULARIZED VERSION")
    print("=" * 70)
    stats = process_scores_modularized(test_scores)
    print(f"\nReturned statistics: {stats}")
    
    print("\n" + "=" * 70)
    print("USING INDIVIDUAL HELPER FUNCTIONS")
    print("=" * 70)
    print(f"Total: {calculate_total(test_scores)}")
    print(f"Average: {calculate_average(test_scores):.2f}")
    print(f"Highest: {find_highest(test_scores)}")
    print(f"Lowest: {find_lowest(test_scores)}")
    
    print("\n" + "=" * 70)
    print("PYTHONIC VERSION (using built-ins)")
    print("=" * 70)
    stats2 = process_scores_pythonic(test_scores)
    
    print("\n" + "=" * 70)
    print("CLASS-BASED APPROACH")
    print("=" * 70)
    score_stats = ScoreStatistics(test_scores)
    score_stats.display()
    print(f"\nStatistics dictionary: {score_stats.to_dict()}")
    
    print("\n" + "=" * 70)
    print("KEY IMPROVEMENTS")
    print("=" * 70)
    print("""
    ✅ Modularization:
       - Separated into single-responsibility functions
       - Each function does one thing well
       - Functions can be tested independently
       - Functions can be reused in other contexts
    
    ✅ Benefits:
       - calculate_total() - Reusable sum calculation
       - calculate_average() - Can be used independently
       - find_highest() - Reusable maximum finder
       - find_lowest() - Reusable minimum finder
       - print_statistics() - Separates display logic
       - process_scores_modularized() - Orchestrates the flow
    
    ✅ Additional Improvements:
       - Added type hints for better code documentation
       - Added error handling for empty lists
       - Added docstrings explaining each function
       - Return values instead of just printing (more flexible)
       - Multiple approaches shown (helper functions, built-ins, class-based)
    """)

