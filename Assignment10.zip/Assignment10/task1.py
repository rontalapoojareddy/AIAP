def discount(price, category):
    """
    Calculate discounted price based on category and price threshold.
    
    Students get:
    - 10% discount (0.9 multiplier) if price > 1000
    - 5% discount (0.95 multiplier) if price <= 1000
    
    Non-students get:
    - 15% discount (0.85 multiplier) if price > 2000
    - No discount (full price) if price <= 2000
    """
    # Refactored version with early returns for better readability
    if category == "student":
        if price > 1000:
            return price * 0.9
        else:
            return price * 0.95
    else:
        if price > 2000:
            return price * 0.85
        else:
            return price


# Alternative refactored version (more concise)
def discount_refactored(price, category):
    """
    Refactored version using combined conditions for better readability.
    """
    if category == "student":
        return price * 0.9 if price > 1000 else price * 0.95
    
    # Non-student category
    return price * 0.85 if price > 2000 else price


# Most readable version with explicit structure
def discount_improved(price, category):
    """
    Improved version with clearer logic flow.
    """
    # Student discounts
    if category == "student":
        if price > 1000:
            return price * 0.9  # 10% off for expensive items
        return price * 0.95  # 5% off for cheaper items
    
    # Non-student discounts
    if price > 2000:
        return price * 0.85  # 15% off for expensive items
    
    return price  # No discount for cheaper items


# Example usage
if __name__ == "__main__":
    # Test cases
    print("Original function:")
    print(f"Student, price 1500: {discount(1500, 'student')}")  # Expected: 1350
    print(f"Student, price 500: {discount(500, 'student')}")    # Expected: 475
    print(f"Regular, price 2500: {discount(2500, 'regular')}")  # Expected: 2125
    print(f"Regular, price 1000: {discount(1000, 'regular')}")  # Expected: 1000
    
    print("\nRefactored function:")
    print(f"Student, price 1500: {discount_refactored(1500, 'student')}")
    print(f"Student, price 500: {discount_refactored(500, 'student')}")
    print(f"Regular, price 2500: {discount_refactored(2500, 'regular')}")
    print(f"Regular, price 1000: {discount_refactored(1000, 'regular')}")

