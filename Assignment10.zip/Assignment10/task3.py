class emp:
    """
    Original class with poor readability.
    Issues:
    - Abbreviated class and method names
    - Single-letter variable names
    - No documentation
    - No type hints
    - Poor method naming
    - No encapsulation/privacy considerations
    """
    def __init__(self, n, s):
        self.n = n
        self.s = s
    
    def inc(self, p):
        self.s = self.s + (self.s * p / 100)
    
    def pr(self):
        print("emp:", self.n, "salary:", self.s)


class Employee:
    """
    Improved Employee class with better naming, encapsulation, and readability.
    
    Represents an employee with a name and salary, with methods to manage salary.
    """
    
    def __init__(self, name: str, salary: float):
        """
        Initialize an Employee object.
        
        Args:
            name: The employee's name
            salary: The employee's initial salary (must be non-negative)
        
        Raises:
            ValueError: If salary is negative
        """
        if salary < 0:
            raise ValueError("Salary cannot be negative")
        
        self._name = name
        self._salary = salary
    
    @property
    def name(self) -> str:
        """Get the employee's name."""
        return self._name
    
    @property
    def salary(self) -> float:
        """Get the employee's current salary."""
        return self._salary
    
    def increase_salary(self, percentage: float) -> None:
        """
        Apply a percentage increase to the employee's salary.
        
        Args:
            percentage: The percentage increase (e.g., 10 for 10% increase)
        
        Raises:
            ValueError: If percentage is negative
        """
        if percentage < 0:
            raise ValueError("Percentage increase cannot be negative")
        
        self._salary = self._salary * (1 + percentage / 100)
    
    def print_info(self) -> None:
        """
        Print the employee's information to the console.
        """
        print(f"Employee: {self._name}, Salary: ${self._salary:,.2f}")
    
    def __str__(self) -> str:
        """
        Return a string representation of the employee.
        
        Returns:
            Formatted string with employee name and salary
        """
        return f"Employee(name='{self._name}', salary=${self._salary:,.2f})"
    
    def __repr__(self) -> str:
        """
        Return a formal string representation of the employee.
        """
        return f"Employee(name='{self._name}', salary={self._salary})"


# Alternative version with more flexible encapsulation
class EmployeeImproved:
    """
    Alternative improved version with public properties using clearer naming.
    This version maintains simplicity while improving readability.
    """
    
    def __init__(self, name: str, salary: float):
        """
        Initialize an Employee object.
        
        Args:
            name: The employee's name
            salary: The employee's initial salary
        """
        self.name = name
        self.salary = salary
    
    def apply_raise(self, percentage: float) -> None:
        """
        Apply a percentage raise to the employee's salary.
        
        Args:
            percentage: The percentage increase (e.g., 10 for 10%)
        """
        self.salary *= (1 + percentage / 100)
    
    def display_info(self) -> None:
        """Display employee information."""
        print(f"Employee: {self.name}, Salary: ${self.salary:,.2f}")
    
    def __str__(self) -> str:
        """String representation of the employee."""
        return f"Employee(name='{self.name}', salary=${self.salary:,.2f})"


# Example usage
if __name__ == "__main__":
    print("=" * 60)
    print("ORIGINAL VERSION")
    print("=" * 60)
    emp1 = emp("John", 50000)
    emp1.pr()
    emp1.inc(10)
    emp1.pr()
    
    print("\n" + "=" * 60)
    print("IMPROVED VERSION (with encapsulation)")
    print("=" * 60)
    employee1 = Employee("Jane", 55000)
    print(employee1)  # Uses __str__
    employee1.increase_salary(10)
    employee1.print_info()
    
    # Demonstrate properties
    print(f"\nName: {employee1.name}")
    print(f"Salary: ${employee1.salary:,.2f}")
    
    print("\n" + "=" * 60)
    print("SIMPLER IMPROVED VERSION")
    print("=" * 60)
    employee2 = EmployeeImproved("Bob", 60000)
    employee2.display_info()
    employee2.apply_raise(15)
    print(employee2)
    
    print("\n" + "=" * 60)
    print("KEY IMPROVEMENTS")
    print("=" * 60)
    print("""
    ✅ Naming Conventions:
       - 'emp' → 'Employee' (clear, descriptive class name)
       - 'n' → 'name' (full, meaningful variable name)
       - 's' → 'salary' (descriptive attribute name)
       - 'inc' → 'increase_salary' or 'apply_raise' (clear method purpose)
       - 'pr' → 'print_info' or 'display_info' (descriptive method name)
    
    ✅ Encapsulation:
       - Used private attributes (_name, _salary) with @property decorators
       - Controls access to internal state
       - Allows validation when setting values
    
    ✅ Readability & Maintainability:
       - Added comprehensive docstrings
       - Added type hints for all parameters and return values
       - Used f-strings for better string formatting
       - Implemented __str__ and __repr__ for better object representation
       - Added input validation (salary cannot be negative)
       - Clear, self-documenting code
    """)

