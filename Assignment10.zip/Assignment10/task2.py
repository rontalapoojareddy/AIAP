def find_common(a, b):
    """
    Original implementation with nested loops.
    Time complexity: O(n*m) where n = len(a), m = len(b)
    Issues:
    - Very slow for large lists
    - May include duplicates in result
    - Inefficient nested iteration
    """
    res = []
    for i in a:
        for j in b:
            if i == j:
                res.append(i)
    return res


def find_common_optimized(a, b):
    """
    Optimized version using sets for O(n+m) time complexity.
    Much faster for large lists and handles duplicates automatically.
    
    Args:
        a: First list
        b: Second list
    
    Returns:
        List of common elements (no duplicates)
    """
    set_b = set(b)  # O(m) - convert b to set for O(1) lookups
    return list(set(i for i in a if i in set_b))  # O(n) iteration + O(1) lookup


def find_common_optimized_v2(a, b):
    """
    Even more concise version using set intersection.
    Cleanest and most Pythonic approach.
    """
    return list(set(a) & set(b))


def find_common_preserve_order(a, b):
    """
    Optimized version that preserves the order of elements from list 'a'
    and avoids duplicates.
    """
    set_b = set(b)
    seen = set()
    result = []
    
    for item in a:
        if item in set_b and item not in seen:
            result.append(item)
            seen.add(item)
    
    return result


# Example usage and performance comparison
if __name__ == "__main__":
    # Test cases
    list1 = [1, 2, 3, 4, 5, 5, 6]
    list2 = [4, 5, 6, 7, 8, 5]
    
    print("Original function:")
    print(f"Input: a={list1}, b={list2}")
    print(f"Result: {find_common(list1, list2)}")  # May have duplicates
    
    print("\nOptimized function (set-based):")
    print(f"Result: {find_common_optimized(list1, list2)}")
    
    print("\nMost concise (set intersection):")
    print(f"Result: {find_common_optimized_v2(list1, list2)}")
    
    print("\nPreserving order from first list:")
    print(f"Result: {find_common_preserve_order(list1, list2)}")
    
    # Performance test with larger lists
    print("\n" + "="*50)
    print("Performance comparison:")
    
    import time
    
    large_a = list(range(1000))
    large_b = list(range(500, 1500))
    
    # Original (commented out for large lists - too slow)
    # start = time.time()
    # result1 = find_common(large_a, large_b)
    # print(f"Original nested loops: {time.time() - start:.4f} seconds")
    
    start = time.time()
    result2 = find_common_optimized(large_a, large_b)
    print(f"Optimized (set-based): {time.time() - start:.6f} seconds")
    
    start = time.time()
    result3 = find_common_optimized_v2(large_a, large_b)
    print(f"Set intersection: {time.time() - start:.6f} seconds")

