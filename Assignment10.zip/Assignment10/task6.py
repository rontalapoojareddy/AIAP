def grade(score):
    """
    Original function with overly complex nested if-else structure.
    Issues:
    - Deeply nested conditionals (4 levels deep)
    - Hard to read and maintain
    - Each else only contains another if-else
    - Poor visual structure
    - Difficult to modify or extend
    """
    if score >= 90:
        return "A"
    else:
        if score >= 80:
            return "B"
        else:
            if score >= 70:
                return "C"
            else:
                if score >= 60:
                    return "D"
                else:
                    return "F"


# ============================================================================
# SIMPLIFIED VERSION USING ELIF
# ============================================================================

def grade_simplified(score: float) -> str:
    """
    Simplified version using elif for clearer logic flow.
    
    This version eliminates deep nesting by using elif (else-if) statements,
    making the code much more readable and maintainable.
    
    Args:
        score: The numerical score to convert to a letter grade
    
    Returns:
        Letter grade: 'A' (90+), 'B' (80-89), 'C' (70-79), 'D' (60-69), 'F' (<60)
    
    Example:
        >>> grade_simplified(95)
        'A'
        >>> grade_simplified(85)
        'B'
        >>> grade_simplified(45)
        'F'
    """
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


# ============================================================================
# ALTERNATIVE: USING LIST-BASED APPROACH
# ============================================================================

def grade_list_based(score: float) -> str:
    """
    Alternative approach using a list of thresholds.
    
    This version uses a data-driven approach that makes it easy to
    modify grade boundaries or add new grades.
    
    Args:
        score: The numerical score to convert to a letter grade
    
    Returns:
        Letter grade based on score thresholds
    """
    # Define grade thresholds (score, grade) - sorted from highest to lowest
    grade_thresholds = [
        (90, "A"),
        (80, "B"),
        (70, "C"),
        (60, "D"),
    ]
    
    for threshold, letter_grade in grade_thresholds:
        if score >= threshold:
            return letter_grade
    
    return "F"  # Default for scores below 60


# ============================================================================
# MOST PYTHONIC: USING BISECT FOR BOUNDARY MATCHING
# ============================================================================

def grade_pythonic(score: float) -> str:
    """
    Most Pythonic approach using bisect module for efficient boundary matching.
    
    This version is especially useful when you have many grade boundaries
    and want optimal performance for lookups.
    
    Args:
        score: The numerical score to convert to a letter grade
    
    Returns:
        Letter grade based on score thresholds
    """
    import bisect
    
    # Breakpoints (thresholds) and corresponding grades
    breakpoints = [60, 70, 80, 90]
    grades = ['F', 'D', 'C', 'B', 'A']
    
    # bisect_right returns the insertion point which gives us the grade index
    index = bisect.bisect_right(breakpoints, score)
    return grades[index]


# ============================================================================
# VERSION WITH BOUNDARY VALIDATION
# ============================================================================

def grade_with_validation(score: float) -> str:
    """
    Version with input validation and clear structure.
    
    This version adds validation to ensure the score is within valid range
    and uses elif for clean, readable logic.
    
    Args:
        score: The numerical score to convert to a letter grade (0-100)
    
    Returns:
        Letter grade: 'A' through 'F'
    
    Raises:
        ValueError: If score is outside the valid range (0-100)
    
    Example:
        >>> grade_with_validation(95)
        'A'
        >>> grade_with_validation(105)
        ValueError: Score must be between 0 and 100, got 105
    """
    # Input validation
    if not (0 <= score <= 100):
        raise ValueError(f"Score must be between 0 and 100, got {score}")
    
    # Simplified logic using elif
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"


# Example usage and testing
if __name__ == "__main__":
    test_scores = [95, 85, 75, 65, 55, 45]
    
    print("=" * 70)
    print("ORIGINAL VERSION (nested if-else)")
    print("=" * 70)
    for score in test_scores:
        result = grade(score)
        print(f"Score: {score:3d} -> Grade: {result}")
    
    print("\n" + "=" * 70)
    print("SIMPLIFIED VERSION (using elif)")
    print("=" * 70)
    for score in test_scores:
        result = grade_simplified(score)
        print(f"Score: {score:3d} -> Grade: {result}")
    
    print("\n" + "=" * 70)
    print("LIST-BASED VERSION (data-driven)")
    print("=" * 70)
    for score in test_scores:
        result = grade_list_based(score)
        print(f"Score: {score:3d} -> Grade: {result}")
    
    print("\n" + "=" * 70)
    print("PYTHONIC VERSION (using bisect)")
    print("=" * 70)
    for score in test_scores:
        result = grade_pythonic(score)
        print(f"Score: {score:3d} -> Grade: {result}")
    
    print("\n" + "=" * 70)
    print("VERSION WITH VALIDATION")
    print("=" * 70)
    for score in test_scores:
        try:
            result = grade_with_validation(score)
            print(f"Score: {score:3d} -> Grade: {result}")
        except ValueError as e:
            print(f"Score: {score:3d} -> Error: {e}")
    
    # Test edge cases
    print("\n" + "=" * 70)
    print("EDGE CASE TESTING")
    print("=" * 70)
    edge_cases = [100, 90, 89.9, 80, 79.9, 70, 69.9, 60, 59.9, 0]
    for score in edge_cases:
        result = grade_simplified(score)
        print(f"Score: {score:5.1f} -> Grade: {result}")
    
    print("\n" + "=" * 70)
    print("KEY IMPROVEMENTS")
    print("=" * 70)
    print("""
    ✅ Simplified Logic:
       - Replaced nested if-else with elif statements
       - Reduced nesting from 4 levels to 1 level
       - Linear flow that's easy to read top-to-bottom
    
    ✅ Readability:
       - Much cleaner and easier to understand
       - Clear sequential logic flow
       - No deep indentation making code hard to follow
    
    ✅ Maintainability:
       - Easy to add new grade thresholds
       - Easy to modify existing boundaries
       - Clear structure for debugging
    
    ✅ Best Practice:
       - elif is the Pythonic way to handle multiple conditions
       - Type hints added for better code documentation
       - Docstrings added for clarity
       - Multiple approaches shown (elif, list-based, bisect)
    """)

