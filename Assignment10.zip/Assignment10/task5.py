def div(a, b):
    """
    Original faulty function.
    Issues:
    - No error handling (will crash with ZeroDivisionError)
    - Poor naming (single letter variables, abbreviated function name)
    - No documentation
    - No type hints
    - No input validation
    """
    return a / b


# print(div(10, 0))  # This will raise ZeroDivisionError - commented out to prevent crash


# ============================================================================
# IMPROVED VERSION WITH PROPER ERROR HANDLING
# ============================================================================

def divide_numbers(dividend: float, divisor: float) -> float:
    """
    Divide two numbers with proper error handling.
    
    This function safely divides two numbers and handles various error cases:
    - Division by zero: Raises a clear ValueError
    - Invalid input types: Raises TypeError
    - Other unexpected errors: Caught and re-raised with context
    
    Args:
        dividend: The number to be divided (numerator)
        divisor: The number to divide by (denominator)
    
    Returns:
        The result of dividing dividend by divisor
    
    Raises:
        ValueError: If divisor is zero (cannot divide by zero)
        TypeError: If inputs are not numeric types
        ZeroDivisionError: If divisor is zero (caught and converted to ValueError)
    
    Example:
        >>> divide_numbers(10, 2)
        5.0
        >>> divide_numbers(10, 0)
        ValueError: Cannot divide by zero. Divisor cannot be 0.
    """
    try:
        # Input validation - check for zero divisor
        if divisor == 0:
            raise ValueError("Cannot divide by zero. Divisor cannot be 0.")
        
        # Perform division
        result = dividend / divisor
        return result
    
    except TypeError as e:
        # Handle case where inputs are not numeric
        raise TypeError(
            f"Invalid input types. Both dividend and divisor must be numbers. "
            f"Got dividend: {type(dividend).__name__}, divisor: {type(divisor).__name__}"
        ) from e
    
    except ZeroDivisionError as e:
        # This shouldn't happen due to our check, but handle it anyway
        raise ValueError("Cannot divide by zero. Divisor cannot be 0.") from e
    
    except Exception as e:
        # Catch any other unexpected errors
        raise RuntimeError(
            f"Unexpected error during division: {type(e).__name__}: {str(e)}"
        ) from e


def divide_numbers_alternative(dividend: float, divisor: float) -> float:
    """
    Alternative version with more concise error handling.
    
    This version uses a simpler approach while still providing good error handling.
    It relies on Python's built-in ZeroDivisionError and provides a clear message.
    
    Args:
        dividend: The number to be divided (numerator)
        divisor: The number to divide by (denominator)
    
    Returns:
        The result of dividing dividend by divisor
    
    Raises:
        ZeroDivisionError: If divisor is zero
        TypeError: If inputs are not numeric types
    
    Example:
        >>> divide_numbers_alternative(10, 2)
        5.0
    """
    try:
        return dividend / divisor
    except ZeroDivisionError:
        raise ZeroDivisionError(
            f"Cannot divide {dividend} by zero. Division by zero is undefined."
        )
    except TypeError as e:
        raise TypeError(
            f"Both arguments must be numbers. "
            f"Received dividend: {type(dividend).__name__}, "
            f"divisor: {type(divisor).__name__}"
        ) from e


def divide_numbers_safe(dividend: float, divisor: float, default: float = None) -> float:
    """
    Safe division function that returns a default value instead of raising an error.
    
    This version handles division by zero gracefully by returning a default value
    rather than raising an exception. Useful when you want to continue execution
    even when division fails.
    
    Args:
        dividend: The number to be divided (numerator)
        divisor: The number to divide by (denominator)
        default: Value to return if divisor is zero (default: None)
    
    Returns:
        The result of dividing dividend by divisor, or default if divisor is zero
    
    Example:
        >>> divide_numbers_safe(10, 0, default=0.0)
        0.0
        >>> divide_numbers_safe(10, 2)
        5.0
    """
    try:
        if divisor == 0:
            if default is not None:
                return default
            raise ValueError("Cannot divide by zero. Provide a default value or handle the error.")
        return dividend / divisor
    except TypeError as e:
        raise TypeError(
            f"Invalid input types. Expected numbers, "
            f"got dividend: {type(dividend).__name__}, divisor: {type(divisor).__name__}"
        ) from e


# Example usage and testing
if __name__ == "__main__":
    print("=" * 70)
    print("ORIGINAL VERSION (will crash)")
    print("=" * 70)
    try:
        result = div(10, 0)
        print(f"Result: {result}")
    except ZeroDivisionError as e:
        print(f"Error: {e}")
        print("The original function crashes with ZeroDivisionError!")
    
    print("\n" + "=" * 70)
    print("IMPROVED VERSION WITH PROPER ERROR HANDLING")
    print("=" * 70)
    
    # Test normal division
    try:
        result = divide_numbers(10, 2)
        print(f"divide_numbers(10, 2) = {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    # Test division by zero
    try:
        result = divide_numbers(10, 0)
        print(f"divide_numbers(10, 0) = {result}")
    except ValueError as e:
        print(f"Caught error: {e}")
    
    # Test invalid input types
    try:
        result = divide_numbers("10", 2)
        print(f"Result: {result}")
    except TypeError as e:
        print(f"Caught TypeError: {e}")
    
    print("\n" + "=" * 70)
    print("ALTERNATIVE VERSION")
    print("=" * 70)
    try:
        result = divide_numbers_alternative(15, 3)
        print(f"divide_numbers_alternative(15, 3) = {result}")
    except Exception as e:
        print(f"Error: {e}")
    
    try:
        result = divide_numbers_alternative(10, 0)
        print(f"Result: {result}")
    except ZeroDivisionError as e:
        print(f"Caught ZeroDivisionError: {e}")
    
    print("\n" + "=" * 70)
    print("SAFE VERSION (with default value)")
    print("=" * 70)
    result = divide_numbers_safe(10, 0, default=0.0)
    print(f"divide_numbers_safe(10, 0, default=0.0) = {result}")
    
    result = divide_numbers_safe(20, 4)
    print(f"divide_numbers_safe(20, 4) = {result}")
    
    print("\n" + "=" * 70)
    print("KEY IMPROVEMENTS")
    print("=" * 70)
    print("""
    ✅ Error Handling:
       - try-except blocks to catch ZeroDivisionError
       - Input validation to check for zero divisor before division
       - Handles TypeError for invalid input types
       - Clear, descriptive error messages
       - Exception chaining (using 'from e') for better debugging
    
    ✅ Naming Conventions:
       - 'div' → 'divide_numbers' (descriptive function name)
       - 'a' → 'dividend' (clear parameter name)
       - 'b' → 'divisor' (descriptive parameter name)
       - Follows Python naming conventions (snake_case)
    
    ✅ Readability & Documentation:
       - Comprehensive docstrings explaining the function
       - Clear description of error handling behavior
       - Type hints for all parameters and return values
       - Examples in docstrings
       - Raises section documenting all possible exceptions
       - Comments explaining error handling logic
    
    ✅ Additional Improvements:
       - Multiple versions shown (strict, alternative, safe)
       - Input validation before performing operations
       - Better error messages with context
       - Exception chaining for debugging
       - Safe version that returns default values instead of raising
    """)

