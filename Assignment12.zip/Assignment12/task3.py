from itertools import combinations

# Objective: maximize 6A + 5B
obj = (6, 5)

# Constraints of the form ax + by <= c
constraints = [
    (1, 1, 5),   # A + B <= 5
    (3, 2, 12)   # 3A + 2B <= 12
]

# Bounds A >= 0, B >= 0 as constraints
axis_constraints = [
    (1, 0, 0),   # A >= 0  -> represented as A = 0 for intersections
    (0, 1, 0)    # B >= 0
]

def solve_equation_pair(eq1, eq2):
    (a1, b1, c1), (a2, b2, c2) = eq1, eq2
    det = a1 * b2 - a2 * b1
    if abs(det) < 1e-9:
        return None
    x = (c1 * b2 - c2 * b1) / det
    y = (a1 * c2 - a2 * c1) / det
    return (x, y)

def is_feasible(point):
    if point is None:
        return False
    x, y = point
    if x < -1e-9 or y < -1e-9:
        return False
    for a, b, c in constraints:
        if a * x + b * y - c > 1e-9:
            return False
    return True

candidates = {(0.0, 0.0)}

all_constraints = constraints + axis_constraints

for eq1, eq2 in combinations(all_constraints, 2):
    point = solve_equation_pair(eq1, eq2)
    if is_feasible(point):
        candidates.add((max(point[0], 0.0), max(point[1], 0.0)))

def objective(point):
    x, y = point
    return obj[0] * x + obj[1] * y

optimal_point = max(candidates, key=objective)
A_opt, B_opt = optimal_point
profit = objective(optimal_point)

print("Optimal A =", round(A_opt))
print("Optimal B =", round(B_opt))
print("Maximum Profit =", profit)
