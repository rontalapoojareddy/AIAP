def print_multiples(number):
    """Print the first 10 multiples of a number using a loop."""
    for i in range(1, 11):
        print(f"{number} × {i} = {number * i}")


# Get user input and call the function
num = int(input("Enter a number: "))
print_multiples(num)