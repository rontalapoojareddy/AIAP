class BankAccount:
    """A BankAccount class with deposit, withdraw, and balance methods."""
    
    def __init__(self, account_holder, initial_balance=0.0):
        """
        Initialize a bank account.
        
        Parameters:
        - account_holder (str): Name of the account holder
        - initial_balance (float): Starting balance (default: 0.0)
        """
        self.account_holder = account_holder
        self.balance = initial_balance
    
    def deposit(self, amount):
        """
        Deposit money into the account.
        
        Parameters:
        - amount (float): Amount to deposit
        
        Returns:
        - bool: True if successful, False otherwise
        """
        if amount > 0:
            self.balance += amount
            print(f"Deposited ${amount:.2f}. New balance: ${self.balance:.2f}")
            return True
        else:
            print("Invalid amount! Deposit amount must be positive.")
            return False
    
    def withdraw(self, amount):
        """
        Withdraw money from the account.
        
        Parameters:
        - amount (float): Amount to withdraw
        
        Returns:
        - bool: True if successful, False otherwise
        """
        if amount > 0:
            if amount <= self.balance:
                self.balance -= amount
                print(f"Withdrew ${amount:.2f}. New balance: ${self.balance:.2f}")
                return True
            else:
                print("Insufficient funds! Cannot withdraw more than balance.")
                return False
        else:
            print("Invalid amount! Withdrawal amount must be positive.")
            return False
    
    def get_balance(self):
        """
        Get the current balance of the account.
        
        Returns:
        - float: Current account balance
        """
        return self.balance
    
    def display_balance(self):
        """Display the account information and current balance."""
        print(f"\nAccount Holder: {self.account_holder}")
        print(f"Current Balance: ${self.balance:.2f}")
        print("-" * 40)


# Main program with user input
def main():
    """Main function to demonstrate BankAccount class with user input."""
    print("=" * 50)
    print("Bank Account Management System")
    print("=" * 50)
    
    # Get account holder name
    name = input("\nEnter account holder name: ").strip()
    
    # Get initial balance
    while True:
        try:
            initial = float(input("Enter initial balance (or 0 for new account): $"))
            if initial >= 0:
                break
            else:
                print("Initial balance cannot be negative.")
        except ValueError:
            print("Invalid input! Please enter a valid number.")
    
    # Create account
    account = BankAccount(name, initial)
    account.display_balance()
    
    # Menu loop
    while True:
        print("\nOptions:")
        print("1. Deposit")
        print("2. Withdraw")
        print("3. Check Balance")
        print("4. Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            try:
                amount = float(input("Enter deposit amount: $"))
                account.deposit(amount)
            except ValueError:
                print("Invalid input! Please enter a valid number.")
        
        elif choice == '2':
            try:
                amount = float(input("Enter withdrawal amount: $"))
                account.withdraw(amount)
            except ValueError:
                print("Invalid input! Please enter a valid number.")
        
        elif choice == '3':
            account.display_balance()
        
        elif choice == '4':
            print("\nThank you for using the Bank Account System!")
            account.display_balance()
            break
        
        else:
            print("Invalid choice! Please select 1-4.")


if __name__ == "__main__":
    main()