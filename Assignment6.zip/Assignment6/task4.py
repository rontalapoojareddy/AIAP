def sum_to_n(n):
    """Calculate the sum of the first n numbers."""
    total = 0
    for i in range(1, n + 1):
        total += i
    return total


# Get user input and calculate
num = int(input("Enter a number (n): "))
result = sum_to_n(num)
print(f"Sum of first {num} numbers = {result}")