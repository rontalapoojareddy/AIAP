def classify_age_group(age):
    """Classify age groups using nested if-elif-else conditionals."""
    
    if age < 0:
        print("Invalid age! Age cannot be negative.")
    elif age < 13:
        print(f"Age {age}: Child")
    elif age < 18:
        print(f"Age {age}: Teenager")
    elif age < 65:
        if age < 30:
            print(f"Age {age}: Young Adult")
        elif age < 50:
            print(f"Age {age}: Adult")
        else:
            print(f"Age {age}: Middle-aged Adult")
    else:
        print(f"Age {age}: Senior")

# Get user input and classify
age = int(input("Enter your age: "))
classify_age_group(age)