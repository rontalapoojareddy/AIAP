class Student:
    """
    A Student class with attributes and methods to manage student information.
    """
    
    def __init__(self, name, student_id, age, major, gpa=0.0):
        """
        Initialize a Student object with basic attributes.
        
        Parameters:
        - name (str): Student's full name
        - student_id (str): Unique student identification number
        - age (int): Student's age
        - major (str): Student's field of study
        - gpa (float): Grade Point Average (default: 0.0)
        """
        self.name = name
        self.student_id = student_id
        self.age = age
        self.major = major
        self.gpa = gpa
    
    def display_info(self):
        """
        Display all student information in a formatted way.
        
        Returns:
        - str: Formatted string with student details
        """
        info = f"""
        Student Information:
        -------------------
        Name: {self.name}
        Student ID: {self.student_id}
        Age: {self.age}
        Major: {self.major}
        GPA: {self.gpa:.2f}
        -------------------
        """
        return info
    
    def update_gpa(self, new_gpa):
        """
        Update the student's GPA.
        
        Parameters:
        - new_gpa (float): New GPA value
        
        Returns:
        - bool: True if update successful, False otherwise
        """
        if 0.0 <= new_gpa <= 4.0:
            self.gpa = new_gpa
            return True
        else:
            print("Error: GPA must be between 0.0 and 4.0")
            return False
    
    def get_grade_level(self):
        """
        Determine the student's grade level based on GPA.
        
        Returns:
        - str: Grade level description
        """
        if self.gpa >= 3.5:
            return "Excellent"
        elif self.gpa >= 3.0:
            return "Good"
        elif self.gpa >= 2.0:
            return "Satisfactory"
        else:
            return "Needs Improvement"
    
    def __str__(self):
        """
        String representation of the Student object.
        """
        return f"Student({self.name}, ID: {self.student_id})"
    
    def __repr__(self):
        """
        Official string representation of the Student object.
        """
        return f"Student(name='{self.name}', student_id='{self.student_id}', age={self.age}, major='{self.major}', gpa={self.gpa})"


def get_student_input():
    """
    Function to get student information from user input.
    
    Returns:
    - Student: A Student object created from user input
    """
    print("=" * 50)
    print("Enter Student Information")
    print("=" * 50)
    
    name = input("Enter student name: ").strip()
    
    student_id = input("Enter student ID: ").strip()
    
    while True:
        try:
            age = int(input("Enter student age: "))
            if age > 0:
                break
            else:
                print("Age must be a positive number. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid number for age.")
    
    major = input("Enter major: ").strip()
    
    while True:
        try:
            gpa = float(input("Enter GPA (0.0 - 4.0): "))
            if 0.0 <= gpa <= 4.0:
                break
            else:
                print("GPA must be between 0.0 and 4.0. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a valid number for GPA.")
    
    return Student(name, student_id, age, major, gpa)


def main():
    """
    Main function to demonstrate the Student class with user input.
    """
    print("\n" + "=" * 50)
    print("Student Management System")
    print("=" * 50 + "\n")
    
    # Get student information from user
    student = get_student_input()
    
    # Display student information
    print("\n" + student.display_info())
    
    # Display additional information
    print(f"Grade Level: {student.get_grade_level()}\n")
    
    # Option to update GPA
    update_choice = input("Would you like to update the GPA? (yes/no): ").strip().lower()
    if update_choice == 'yes':
        while True:
            try:
                new_gpa = float(input("Enter new GPA (0.0 - 4.0): "))
                if student.update_gpa(new_gpa):
                    print(f"\nGPA updated successfully!")
                    print(student.display_info())
                    print(f"Grade Level: {student.get_grade_level()}\n")
                    break
            except ValueError:
                print("Invalid input. Please enter a valid number for GPA.")
    
    # Display string representations
    print("String representation:", student)
    print("Official representation:", repr(student))


if __name__ == "__main__":
    main()