"""Few-shot prompted function: count number of lines in a .txt file.

Few-shot examples (I/O behavior we want):
- Example 1: empty file -> 0
- Example 2: file with "Hello\n" -> 1
- Example 3: file with "a\nb\nc" (no trailing newline) -> 3

Rules clarified by examples:
- Count logical lines separated by newline characters.
- The last line counts even if the file does not end with a newline.
- Assume UTF-8 text files.
"""

from __future__ import annotations

from typing import Text


def read_txt_line_count(file_path: Text) -> int:
    """Return the number of lines in a UTF-8 .txt file.

    Behavior is aligned with the few-shot examples above.
    """
    count = 0
    with open(file_path, "r", encoding="utf-8") as f:
        for _ in f:
            count += 1
    return count


if __name__ == "__main__":
    # Small demo using temporary files to mirror the few-shot examples.
    import tempfile
    import os

    examples = [
        ("", 0),                # empty -> 0
        ("Hello\n", 1),         # one line with trailing newline -> 1
        ("a\nb\nc", 3),        # three lines without trailing newline -> 3
    ]

    for content, expected in examples:
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".txt", encoding="utf-8") as tf:
            tf.write(content)
            temp_path = tf.name
        try:
            result = read_txt_line_count(temp_path)
            print(f"{os.path.basename(temp_path)} -> lines: {result} (expected {expected})")
        finally:
            os.unlink(temp_path)

