"""Single-file Leap Year Checker

This script contains:
- `is_leap_year(year: int) -> bool` — the implementation using Gregorian rules
- a small built-in test runner (runs when executed with no args)
- a minimal CLI: pass a year as the first argument to check a single year

Gregorian rules summary:
- Years divisible by 4 are leap years,
- except years divisible by 100 are not leap years,
- except years divisible by 400 are leap years.

Usage examples (PowerShell):

    # Run the built-in tests
    python "c:\\Users\\anred\\OneDrive\\Desktop\\AIAP\\Assignments\\Assignment 4\\leap_year.py"

    # Check a single year
    python "c:\\Users\\anred\\OneDrive\\Desktop\\AIAP\\Assignments\\Assignment 4\\leap_year.py" 2024

The function raises TypeError for non-integer inputs.
"""

from typing import Iterable, Tuple
import sys


def is_leap_year(year: int) -> bool:
    """Return True if `year` is a leap year according to Gregorian rules.

    Args:
        year: integer year to check. Zero and negative integers are accepted and
              follow the same arithmetic rules.

    Returns:
        True if `year` is a leap year, False otherwise.

    Raises:
        TypeError: if `year` is not an integer.
    """
    if not isinstance(year, int):
        raise TypeError("year must be an integer")

    # Leap if divisible by 4 AND (not divisible by 100 OR divisible by 400)
    return (year % 4 == 0) and (year % 100 != 0 or year % 400 == 0)


def _test_cases() -> Iterable[Tuple[int, bool]]:
    """Return a sequence of (year, expected) test cases."""
    return [
        (2000, True),   # divisible by 400 -> leap
        (1900, False),  # divisible by 100 but not 400 -> not leap
        (2004, True),   # divisible by 4 -> leap
        (2001, False),  # not divisible by 4 -> not leap
        (2400, True),   # divisible by 400 -> leap
        (2100, False),  # divisible by 100 but not 400 -> not leap
        (0, True),      # year 0 -> divisible by 400
        (-4, True),     # negative but divisible by 4
    ]


def run_tests() -> bool:
    """Run built-in tests. Prints concise results and returns True when all pass."""
    all_ok = True
    for y, expected in _test_cases():
        got = is_leap_year(y)
        # Only print the year and whether it's a leap year
        print(f"{y}: {'leap' if got else 'not leap'}")
        if got != expected:
            all_ok = False

    # Type enforcement check — expected to raise TypeError. Do not print this
    try:
        is_leap_year(2000.0)  # type: ignore[arg-type]
    except TypeError:
        pass
    else:
        all_ok = False

    return all_ok


def _usage() -> str:
    return (
        "Usage:\n"
        "  (no args)    -> run built-in tests\n"
        "  <year>       -> print whether <year> is a leap year\n"
        "Examples:\n"
        "  python leap_year.py\n"
        "  python leap_year.py 2024\n"
    )


def main(argv=None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    if not argv:
        ok = run_tests()
        return 0 if ok else 1

    a0 = argv[0]
    if a0 in ("-h", "--help"):
        print(_usage())
        return 0

    # Try parse integer year
    try:
        year = int(a0)
    except ValueError:
        print(f"Error: year must be an integer (got: {a0!r})")
        print(_usage())
        return 2

    # Minimal output: only year and whether it's a leap year
    print(f"{year}: {'leap' if is_leap_year(year) else 'not leap'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
"""Single-file Leap Year Checker

This script contains:
- `is_leap_year(year: int) -> bool` — the implementation using Gregorian rules
- a small built-in test runner (runs when executed with no args)
- a minimal CLI: pass a year as the first argument to check a single year

Gregorian rules summary:
- Years divisible by 4 are leap years,
- except years divisible by 100 are not leap years,
- except years divisible by 400 are leap years.

Usage examples (PowerShell):

    # Run the built-in tests
    python "c:\\Users\\anred\\OneDrive\\Desktop\\AIAP\\Assignments\\Assignment 4\\leap_year.py"

    # Check a single year
    python "c:\\Users\\anred\\OneDrive\\Desktop\\AIAP\\Assignments\\Assignment 4\\leap_year.py" 2024

The function raises TypeError for non-integer inputs.
"""

from typing import Iterable, Tuple
import sys


def is_leap_year(year: int) -> bool:
    """Return True if `year` is a leap year according to Gregorian rules.

    Args:
        year: integer year to check. Zero and negative integers are accepted and
              follow the same arithmetic rules.

    Returns:
        True if `year` is a leap year, False otherwise.

    Raises:
        TypeError: if `year` is not an integer.
    """
    if not isinstance(year, int):
        raise TypeError("year must be an integer")

    # Leap if divisible by 4 AND (not divisible by 100 OR divisible by 400)
    return (year % 4 == 0) and (year % 100 != 0 or year % 400 == 0)


def _test_cases() -> Iterable[Tuple[int, bool]]:
    """Return a sequence of (year, expected) test cases."""
    return [
        (2000, True),   # divisible by 400 -> leap
        (1900, False),  # divisible by 100 but not 400 -> not leap
        (2004, True),   # divisible by 4 -> leap
        (2001, False),  # not divisible by 4 -> not leap
        (2400, True),   # divisible by 400 -> leap
        (2100, False),  # divisible by 100 but not 400 -> not leap
        (0, True),      # year 0 -> divisible by 400
        (-4, True),     # negative but divisible by 4
    ]


def run_tests() -> bool:
    """Run built-in tests. Prints results and returns True when all pass."""
    all_ok = True
    for y, expected in _test_cases():
        got = is_leap_year(y)
        print(f"year={y}: expected={expected}, got={got}")
        if got != expected:
            all_ok = False
            print(f"  -> MISMATCH for {y}")

    # Type enforcement check
    try:
        is_leap_year(2000.0)  # type: ignore[arg-type]
    except TypeError:
        print("type check: OK (float raises TypeError)")
    else:
        print("type check: FAIL (float did not raise TypeError)")
        all_ok = False

    if all_ok:
        print("All tests passed")
    else:
        print("Some tests failed")

    return all_ok


def _usage() -> str:
    return (
        "Usage:\n"
        "  (no args)    -> run built-in tests\n"
        "  <year>       -> print whether <year> is a leap year\n"
        "Examples:\n"
        "  python leap_year.py\n"
        "  python leap_year.py 2024\n"
    )


def main(argv=None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    if not argv:
        ok = run_tests()
        return 0 if ok else 1

    a0 = argv[0]
    if a0 in ("-h", "--help"):
        print(_usage())
        return 0

    # Try parse integer year
    try:
        year = int(a0)
    except ValueError:
        print(f"Error: year must be an integer (got: {a0!r})")
        print(_usage())
        return 2

    print(f"{year} is a leap year: {is_leap_year(year)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())