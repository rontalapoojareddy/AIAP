# Zero-shot vs Few-shot prompt demonstration (vowel counter)
# ---------------------------------------------------------
# This file shows two ways an AI (or a developer prompted by an AI)
# might implement a function to count vowels in a string.
#
# 1) Zero-shot: No examples provided in the prompt.
#    - The instruction is broad, so interpretation can vary
#      (e.g., which vowels to consider, how to handle case/accents).
#    - Implementation below: a straightforward approach the AI might infer.

# 2) Few-shot: Prompt includes 2–3 concrete input-output examples.
#    - Examples constrain behavior (ASCII vowels only, case-insensitive).
#    - Reduces ambiguity and increases consistency on edge cases.


def count_vowels_zero_shot(s: str) -> int:
    """Zero-shot-style implementation: simple, inferred behavior.

    Assumptions (implicit due to lack of examples):
    - Case-insensitive counting of standard English vowels a, e, i, o, u
    - Does not count accented characters (e.g., 'é') unless explicitly stated
    - Non-letters are ignored naturally because they are not in the vowel set
    """
    vowels = set("aeiouAEIOU")
    return sum(1 for ch in s if ch in vowels)


def count_vowels_few_shot(s: str) -> int:
    """Few-shot-guided implementation: behavior clarified by examples.

    Given examples like:
      - "Hello" -> 2
      - "AEIOU" -> 5
      - "Rhythm" -> 0

    We codify explicit rules consistent with those examples:
    - Consider only ASCII vowels {a, e, i, o, u}
    - Case-insensitive (normalize to lowercase before counting)
    - Ignore non-ASCII vowels/accents (e.g., 'é' not counted)
    """
    ascii_vowels = set("aeiou")  # constrained by examples
    return sum(1 for ch in s.lower() if ch in ascii_vowels)


if __name__ == "__main__":
    # Demo inputs aligned with the few-shot examples
    samples = [
        "Hello",           # few-shot says -> 2
        "AEIOU",           # -> 5
        "Rhythm",          # -> 0
        "naïve café",      # shows accented letters are not counted under ASCII-only rule
    ]

    print("Zero-shot results:")
    for text in samples:
        print(f"  '{text}' -> {count_vowels_zero_shot(text)}")

    print("\nFew-shot-guided results:")
    for text in samples:
        print(f"  '{text}' -> {count_vowels_few_shot(text)}")

    # Key difference summary (as code comments above):
    # - Zero-shot: basic, reasonable defaults; may differ on edge cases.
    # - Few-shot: examples make behavior explicit (ASCII-only, case-insensitive),
    #             improving consistency and predictability.

