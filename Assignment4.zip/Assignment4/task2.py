def cm_to_inches(centimeters: float) -> float:
    """Convert centimeters to inches.

    1 inch = 2.54 centimeters.
    """
    inches_per_centimeter = 1.0 / 2.54
    return centimeters * inches_per_centimeter


if __name__ == "__main__":
    example_cm = 25.4
    result_in = cm_to_inches(example_cm)
    # Expect: 10.0
    print(f"Input (cm): {example_cm} -> Output (in): {result_in}")

