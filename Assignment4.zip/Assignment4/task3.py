def format_full_name(full_name: str) -> str:
    """Format a full name as 'Last, First [Middle]'.

    Assumes the last token is the last name; everything before it is first/middle.
    If only one token is provided, returns it unchanged.
    """
    parts = full_name.strip().split()
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    last = parts[-1]
    first_and_middle = " ".join(parts[:-1])
    return f"{last}, {first_and_middle}"
if __name__ == "__main__":
    examples = [
        "Ada Lovelace",
        "John A. Smith",
        "Mary Jane Watson-Parker",
    ]
    for name in examples:
        print(f"Input: {name} -> Output: {format_full_name(name)}")

