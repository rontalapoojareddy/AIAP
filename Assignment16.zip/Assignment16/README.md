# Sample Database: `sample_db`

This folder contains a small MySQL sample database script and instructions to run it.

Files:
- `sample_db.sql`: SQL script that creates the `sample_db` database, an `employees` table, and inserts sample rows.

How to run (Windows PowerShell):

1. Open PowerShell.
2. Change directory to the folder containing the script or provide its absolute path.

Run using MySQL CLI (replace user and path as needed):

```powershell
# If your MySQL root user has a password, you'll be prompted for it
mysql -u root -p < "c:\Users\anred\OneDrive\Desktop\AIAP\Assignments\Assignment16\sample_db.sql"

# Or, if you are already in the script folder:
mysql -u root -p < .\sample_db.sql
```

If you use XAMPP, ensure MySQL is running, then run the same `mysql` command from a shell that has the `mysql` client in PATH (or use the full path to the `mysql.exe` in XAMPP's `mysql\bin`).

Verifying the database (optional):

```powershell
# Connect to MySQL interactively
mysql -u root -p
# Then inside mysql:
USE sample_db;
SELECT * FROM employees;
```

Notes:
- The script drops `sample_db` if it exists, then recreates it, so be careful if you have an existing database with that name.
- Adjust the `-u` value if you use a different MySQL user.

Views:
- `high_salary_employees`: employees with salary >= 80000.
- `employee_departments`: shows employee `full_name` and `department` (created after a small `departments` table is added and employees are mapped to departments).

To view employee names and departments after running the script, connect interactively and run:
```powershell
mysql -u root -p
# then inside mysql:
USE sample_db;
SELECT * FROM employee_departments;
```
