-- ============================================
-- TESTING BOOK AVAILABILITY UPDATE FEATURE
-- ============================================

-- Test 1: Check initial book availability
SELECT book_id, title, available_copies, is_available 
FROM books 
WHERE book_id = 1;

-- Test 2: Create a new loan (this will trigger availability update)
INSERT INTO loans (book_id, member_id, loan_date, due_date, status) 
VALUES (1, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Active');

-- Test 3: Check availability after borrowing (should be updated automatically)
SELECT book_id, title, available_copies, is_available 
FROM books 
WHERE book_id = 1;

-- Test 4: Borrow more copies until availability becomes FALSE
-- (Assuming book_id 1 has multiple copies)
INSERT INTO loans (book_id, member_id, loan_date, due_date, status) 
VALUES (1, 2, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Active');

INSERT INTO loans (book_id, member_id, loan_date, due_date, status) 
VALUES (1, 3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Active');

-- Check if is_available is now FALSE
SELECT book_id, title, available_copies, is_available 
FROM books 
WHERE book_id = 1;

-- Test 5: Return a book (this will trigger availability update)
UPDATE loans 
SET status = 'Returned', return_date = CURDATE() 
WHERE book_id = 1 
AND member_id = 1 
AND status = 'Active'
LIMIT 1;

-- Check availability after return (should be updated automatically)
SELECT book_id, title, available_copies, is_available 
FROM books 
WHERE book_id = 1;

-- ============================================
-- TESTING SAFE MEMBER DELETION FEATURE
-- ============================================

-- Test 1: Try to delete a member with active loans (should FAIL)
-- Member 2 has an active loan (check loans table)
SELECT member_id, first_name, last_name 
FROM members 
WHERE member_id = 2;

SELECT loan_id, book_id, status 
FROM loans 
WHERE member_id = 2 AND status IN ('Active', 'Overdue');

-- This should fail with an error message
CALL delete_member_safely(2);

-- Test 2: Return all books for a member first
UPDATE loans 
SET status = 'Returned', return_date = CURDATE() 
WHERE member_id = 2 AND status IN ('Active', 'Overdue');

-- Verify no active loans
SELECT COUNT(*) AS active_loans_count
FROM loans 
WHERE member_id = 2 AND status IN ('Active', 'Overdue');

-- Test 3: Now try to delete (should SUCCEED)
CALL delete_member_safely(2);

-- Verify member is deleted
SELECT * FROM members WHERE member_id = 2;

-- Test 4: Try to delete a non-existent member (should FAIL)
CALL delete_member_safely(999);

-- Test 5: Delete a member with only returned loans (should SUCCEED)
-- First, check member 1's loans
SELECT member_id, COUNT(*) AS total_loans,
       SUM(CASE WHEN status = 'Returned' THEN 1 ELSE 0 END) AS returned_loans,
       SUM(CASE WHEN status IN ('Active', 'Overdue') THEN 1 ELSE 0 END) AS active_loans
FROM loans
WHERE member_id = 1
GROUP BY member_id;

-- If member 1 has no active loans, delete them
CALL delete_member_safely(1);

-- Verify deletion
SELECT * FROM members WHERE member_id = 1;

