-- sample_db.sql
-- Create a sample database and table with example data

DROP DATABASE IF EXISTS sample_db;
CREATE DATABASE sample_db;
USE sample_db;

-- Create departments table with dept_id, dept_name, and location FIRST
DROP TABLE IF EXISTS departments;
CREATE TABLE departments (
  dept_id INT AUTO_INCREMENT PRIMARY KEY,
  dept_name VARCHAR(100) NOT NULL UNIQUE,
  location VARCHAR(100) NOT NULL
);

INSERT INTO departments (dept_name, location) VALUES
('Engineering', 'New York'),
('HR', 'Boston'),
('Sales', 'San Francisco'),
('Finance', 'Chicago'),
('Marketing', 'Los Angeles'),
('IT', 'Seattle'),
('Operations', 'Bangalore');

-- Create employees table with department_id column
CREATE TABLE employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  hire_date DATE NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  department_id INT NOT NULL
);

INSERT INTO employees (first_name, last_name, email, hire_date, salary, department_id) VALUES
('Alice', 'Johnson', 'alice.johnson@example.com', '2021-06-15', 70000.00, (SELECT dept_id FROM departments WHERE dept_name = 'Engineering')),
('Bob', 'Martinez', 'bob.martinez@example.com', '2019-09-01', 82000.50, (SELECT dept_id FROM departments WHERE dept_name = 'IT')),
('Carol', 'Singh', 'carol.singh@example.com', '2020-03-12', 68000.75, (SELECT dept_id FROM departments WHERE dept_name = 'HR')),
('David', 'Nguyen', 'david.nguyen@example.com', '2018-11-20', 95000.00, (SELECT dept_id FROM departments WHERE dept_name = 'Engineering')),
('Eva', 'Lopez', 'eva.lopez@example.com', '2022-01-05', 60000.00, (SELECT dept_id FROM departments WHERE dept_name = 'Operations')),
('Frank', 'O''Connor', 'frank.oconnor@example.com', '2017-07-23', 88000.00, (SELECT dept_id FROM departments WHERE dept_name = 'Finance')),
('Grace', 'Kim', 'grace.kim@example.com', '2023-04-30', 54000.00, (SELECT dept_id FROM departments WHERE dept_name = 'IT')),
('Hassan', 'Ali', 'hassan.ali@example.com', '2020-12-01', 81000.25, (SELECT dept_id FROM departments WHERE dept_name = 'Sales')),
('Jennifer', 'Brown', 'jennifer.brown@example.com', '2020-08-10', 65000.00, (SELECT dept_id FROM departments WHERE dept_name = 'HR'));

-- Show table content (optional when running interactively)
SELECT * FROM employees;

-- Create a view showing employees with salary >= 80000
DROP VIEW IF EXISTS high_salary_employees;
CREATE VIEW high_salary_employees AS
SELECT id, first_name, last_name, email, salary
FROM employees
WHERE salary >= 80000.00;

-- Example: show the view contents
SELECT * FROM high_salary_employees;

-- Create a view to display employee names and their departments
DROP VIEW IF EXISTS employee_departments;
CREATE VIEW employee_departments AS
SELECT e.id,
       CONCAT(e.first_name, ' ', e.last_name) AS full_name,
       d.dept_name AS department,
       d.location
FROM employees e
JOIN departments d ON e.department_id = d.dept_id;

-- Example: show names + departments
SELECT * FROM employee_departments ORDER BY full_name;



SELECT id, CONCAT(first_name, ' ', last_name) AS full_name, salary
FROM employees
WHERE salary > 50000;


SELECT e.id, CONCAT(e.first_name, ' ', e.last_name) AS full_name, e.email, e.salary
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE d.dept_name = 'IT'
ORDER BY e.last_name;


SELECT * FROM employee_departments WHERE department = 'IT';

SELECT id, CONCAT(first_name, ' ', last_name) AS full_name, email, salary, 
       (SELECT dept_name FROM departments WHERE dept_id = employees.department_id) AS department
FROM employees
ORDER BY salary DESC;

SELECT COUNT(*) AS total_employees
FROM employees;

SELECT d.dept_name AS department, AVG(e.salary) AS average_salary
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
GROUP BY d.dept_id, d.dept_name
ORDER BY average_salary DESC;

SELECT MAX(salary) AS maximum_salary, MIN(salary) AS minimum_salary
FROM employees;

SELECT d.dept_name AS department, COUNT(e.id) AS employee_count
FROM departments d
JOIN employees e ON d.dept_id = e.department_id
GROUP BY d.dept_id, d.dept_name
HAVING COUNT(e.id) > 1
ORDER BY employee_count DESC;

-- Display all departments
SELECT * FROM departments;
SELECT * FROM employees;
SELECT e.id, CONCAT(e.first_name, ' ', e.last_name) AS full_name, e.email, e.salary, d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE d.location = 'Bangalore'
ORDER BY e.last_name;
SELECT * FROM employee_departments WHERE location = 'Bangalore';

SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.email, 
       e.salary, 
       e.hire_date,
       d.dept_id,
       d.dept_name AS department,
       d.location
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
ORDER BY e.last_name;

SELECT * FROM employee_departments;

SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.email, 
       e.salary,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE e.salary > (SELECT AVG(salary) FROM employees)
ORDER BY e.salary DESC;

SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.email, 
       e.salary,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE d.dept_name = 'IT'
ORDER BY e.salary DESC
LIMIT 1;


SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.salary,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE d.dept_name = 'HR';

-- Give a 10% salary hike to all employees in the HR department
UPDATE employees e
JOIN departments d ON e.department_id = d.dept_id
SET e.salary = e.salary * 1.10
WHERE d.dept_name = 'HR';

-- Display HR employees after salary hike
SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.salary,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE d.dept_name = 'HR';

-- Display employees who joined before 2020-01-01
SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name,
       e.hire_date,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE e.hire_date < '2020-01-01';

-- Delete employees who joined before 2020-01-01
DELETE FROM employees
WHERE hire_date < '2020-01-01';

-- Display remaining employees
SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name,
       e.hire_date,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
ORDER BY e.hire_date;


SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.email,
       e.salary,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
ORDER BY e.salary DESC
LIMIT 3;



SELECT e.id, 
       CONCAT(e.first_name, ' ', e.last_name) AS full_name, 
       e.email,
       e.salary,
       e.hire_date,
       d.dept_name AS department
FROM employees e
JOIN departments d ON e.department_id = d.dept_id
WHERE e.first_name LIKE 'A%'
ORDER BY e.first_name;

select * from employees;
select * from departments;


-- Update department names
UPDATE departments SET dept_name = 'Software Engineering' WHERE dept_name = 'Engineering';
UPDATE departments SET dept_name = 'Human Resources' WHERE dept_name = 'HR';
UPDATE departments SET dept_name = 'Business Development' WHERE dept_name = 'Sales';
UPDATE departments SET dept_name = 'Financial Services' WHERE dept_name = 'Finance';
UPDATE departments SET dept_name = 'Digital Marketing' WHERE dept_name = 'Marketing';
UPDATE departments SET dept_name = 'Information Technology' WHERE dept_name = 'IT';
UPDATE departments SET dept_name = 'Business Operations' WHERE dept_name = 'Operations';

-- Verify the updated department names
SELECT * FROM departments;


ALTER TABLE departments ADD COLUMN contact_email VARCHAR(100);

-- Update departments with contact emails
UPDATE departments SET contact_email = 'eng@company.com' WHERE dept_name = 'Software Engineering';
UPDATE departments SET contact_email = 'hr@company.com' WHERE dept_name = 'Human Resources';
UPDATE departments SET contact_email = 'sales@company.com' WHERE dept_name = 'Business Development';
UPDATE departments SET contact_email = 'finance@company.com' WHERE dept_name = 'Financial Services';
UPDATE departments SET contact_email = 'marketing@company.com' WHERE dept_name = 'Digital Marketing';
UPDATE departments SET contact_email = 'it@company.com' WHERE dept_name = 'Information Technology';
UPDATE departments SET contact_email = 'ops@company.com' WHERE dept_name = 'Business Operations';

-- Verify the updated departments table
SELECT * FROM departments;

-- Create projects table
DROP TABLE IF EXISTS projects;
CREATE TABLE projects (
  project_id INT AUTO_INCREMENT PRIMARY KEY,
  project_name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  start_date DATE NOT NULL,
  end_date DATE,
  budget DECIMAL(12,2),
  employee_id INT NOT NULL,
  FOREIGN KEY (employee_id) REFERENCES employees(id) ON UPDATE CASCADE ON DELETE CASCADE
);

-- Insert sample projects
INSERT INTO projects (project_name, description, start_date, end_date, budget, employee_id) VALUES
('Website Redesign', 'Redesign company website', '2023-01-15', '2023-06-30', 50000.00, (SELECT id FROM employees WHERE first_name = 'Alice' LIMIT 1)),
('Mobile App Development', 'Develop iOS and Android app', '2023-02-01', '2023-12-31', 120000.00, (SELECT id FROM employees WHERE first_name = 'Bob' LIMIT 1)),
('Data Migration', 'Migrate legacy data to cloud', '2023-03-01', '2023-09-30', 75000.00, (SELECT id FROM employees WHERE first_name = 'Carol' LIMIT 1)),
('Cloud Infrastructure Setup', 'Setup AWS cloud infrastructure', '2023-04-01', '2023-08-31', 85000.00, (SELECT id FROM employees WHERE first_name = 'Grace' LIMIT 1)),
('Marketing Campaign', 'Digital marketing campaign Q4', '2023-09-01', '2023-12-31', 45000.00, (SELECT id FROM employees WHERE first_name = 'Eva' LIMIT 1));

-- Display projects with employee details
SELECT p.project_id,
       p.project_name,
       p.description,
       p.start_date,
       p.end_date,
       p.budget,
       CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
       e.email
FROM projects p
JOIN employees e ON p.employee_id = e.id
ORDER BY p.start_date;


