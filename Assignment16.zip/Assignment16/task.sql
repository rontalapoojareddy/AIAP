-- Library Management System Schema
-- Create database
DROP DATABASE IF EXISTS library_management;
CREATE DATABASE library_management;
USE library_management;

-- Create Books table
CREATE TABLE books (
  book_id INT AUTO_INCREMENT PRIMARY KEY,
  isbn VARCHAR(20) NOT NULL UNIQUE,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(100) NOT NULL,
  publisher VARCHAR(100),
  publication_date DATE,
  category VARCHAR(50),
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  is_available BOOLEAN DEFAULT TRUE,
  price DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Members table
CREATE TABLE members (
  member_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(15),
  address TEXT,
  city VARCHAR(50),
  postal_code VARCHAR(10),
  membership_date DATE NOT NULL,
  membership_type ENUM('Standard', 'Premium', 'Student') DEFAULT 'Standard',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Loans table
CREATE TABLE loans (
  loan_id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  member_id INT NOT NULL,
  loan_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE,
  fine_amount DECIMAL(10,2) DEFAULT 0.00,
  status ENUM('Active', 'Returned', 'Overdue') DEFAULT 'Active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (book_id) REFERENCES books(book_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (member_id) REFERENCES members(member_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- Insert sample books
INSERT INTO books (isbn, title, author, publisher, publication_date, category, total_copies, available_copies, price) VALUES
('978-0-06-112008-4', 'To Kill a Mockingbird', 'Harper Lee', 'J.B. Lippincott', '1960-07-11', 'Fiction', 5, 3, 18.99),
('978-0-7475-3269-9', 'Harry Potter and the Philosopher''s Stone', 'J.K. Rowling', 'Bloomsbury', '1997-06-26', 'Fantasy', 8, 4, 15.99),
('978-0-06-093546-7', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Scribner', '1925-04-10', 'Fiction', 4, 2, 12.99),
('978-0-451-52493-2', '1984', 'George Orwell', 'Secker & Warburg', '1949-06-08', 'Dystopian', 6, 2, 14.99),
('978-0-7432-7356-5', 'The Da Vinci Code', 'Dan Brown', 'Doubleday', '2003-03-18', 'Mystery', 7, 5, 17.99),
('978-0-345-39180-3', 'The Hobbit', 'J.R.R. Tolkien', 'Allen & Unwin', '1937-09-21', 'Fantasy', 5, 3, 16.99),
('978-0-14-028329-7', 'Pride and Prejudice', 'Jane Austen', 'T. Egerton', '1813-01-28', 'Romance', 6, 4, 10.99),
('978-0-06-085052-4', 'Eat, Pray, Love', 'Elizabeth Gilbert', 'Viking', '2006-02-13', 'Biography', 4, 2, 16.99);

-- Insert sample members
INSERT INTO members (first_name, last_name, email, phone, address, city, postal_code, membership_date, membership_type, is_active) VALUES
('John', 'Smith', 'john.smith@email.com', '555-0101', '123 Main St', 'New York', '10001', '2022-01-15', 'Standard', TRUE),
('Sarah', 'Johnson', 'sarah.johnson@email.com', '555-0102', '456 Oak Ave', 'Boston', '02101', '2021-06-20', 'Premium', TRUE),
('Michael', 'Williams', 'michael.williams@email.com', '555-0103', '789 Pine Rd', 'Chicago', '60601', '2023-03-10', 'Student', TRUE),
('Emily', 'Brown', 'emily.brown@email.com', '555-0104', '321 Elm St', 'Los Angeles', '90001', '2022-09-05', 'Standard', TRUE),
('Robert', 'Davis', 'robert.davis@email.com', '555-0105', '654 Maple Dr', 'Houston', '77001', '2023-01-22', 'Premium', TRUE),
('Lisa', 'Miller', 'lisa.miller@email.com', '555-0106', '987 Cedar Ln', 'Phoenix', '85001', '2022-11-30', 'Student', TRUE),
('James', 'Wilson', 'james.wilson@email.com', '555-0107', '147 Birch Way', 'Philadelphia', '19101', '2023-02-14', 'Standard', TRUE),
('Jennifer', 'Moore', 'jennifer.moore@email.com', '555-0108', '258 Spruce St', 'San Antonio', '78201', '2022-07-18', 'Premium', TRUE);

-- Insert sample loans
INSERT INTO loans (book_id, member_id, loan_date, due_date, return_date, status) VALUES
(1, 1, '2023-10-01', '2023-10-15', '2023-10-14', 'Returned'),
(2, 2, '2023-10-05', '2023-10-19', NULL, 'Active'),
(3, 3, '2023-09-20', '2023-10-04', NULL, 'Overdue'),
(4, 4, '2023-10-08', '2023-10-22', NULL, 'Active'),
(5, 5, '2023-09-15', '2023-09-29', '2023-10-05', 'Returned'),
(6, 6, '2023-10-10', '2023-10-24', NULL, 'Active'),
(7, 7, '2023-10-02', '2023-10-16', '2023-10-16', 'Returned'),
(8, 8, '2023-10-12', '2023-10-26', NULL, 'Active'),
(1, 3, '2023-10-15', '2023-10-29', NULL, 'Active'),
(2, 4, '2023-10-18', '2023-11-01', NULL, 'Active');

-- Create view for available books
DROP VIEW IF EXISTS available_books;
CREATE VIEW available_books AS
SELECT book_id, isbn, title, author, category, available_copies, total_copies
FROM books
WHERE available_copies > 0;

-- Create view for active loans
DROP VIEW IF EXISTS active_loans;
CREATE VIEW active_loans AS
SELECT l.loan_id,
       b.title AS book_title,
       CONCAT(m.first_name, ' ', m.last_name) AS member_name,
       m.email,
       l.loan_date,
       l.due_date,
       l.status
FROM loans l
JOIN books b ON l.book_id = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE l.status IN ('Active', 'Overdue');

-- Create view for overdue books
DROP VIEW IF EXISTS overdue_loans;
CREATE VIEW overdue_loans AS
SELECT l.loan_id,
       b.title AS book_title,
       CONCAT(m.first_name, ' ', m.last_name) AS member_name,
       m.email,
       l.loan_date,
       l.due_date,
       DATEDIFF(CURDATE(), l.due_date) AS days_overdue
FROM loans l
JOIN books b ON l.book_id = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE l.status = 'Overdue';

-- Display all books
SELECT * FROM books;

-- Display all members
SELECT * FROM members;

-- Display all loans
SELECT * FROM loans;

-- Display available books
SELECT * FROM available_books;

-- Display active loans
SELECT * FROM active_loans;

-- Display overdue loans
SELECT * FROM overdue_loans;

-- Query: Books borrowed by a specific member
SELECT b.title, b.author, l.loan_date, l.due_date, l.status
FROM loans l
JOIN books b ON l.book_id = b.book_id
WHERE l.member_id = 1;

-- Query: Members with overdue books
SELECT DISTINCT m.member_id, CONCAT(m.first_name, ' ', m.last_name) AS member_name, m.email
FROM members m
JOIN loans l ON m.member_id = l.member_id
WHERE l.status = 'Overdue';

-- Query: Book availability status
SELECT title, author, total_copies, available_copies, (total_copies - available_copies) AS borrowed_copies
FROM books
ORDER BY available_copies DESC;

-- Query: Member loan history
SELECT CONCAT(m.first_name, ' ', m.last_name) AS member_name,
       b.title,
       l.loan_date,
       l.return_date,
       DATEDIFF(l.return_date, l.loan_date) AS days_borrowed
FROM loans l
JOIN books b ON l.book_id = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE l.status = 'Returned'
ORDER BY m.member_id, l.return_date DESC;



SELECT b.book_id,
       b.isbn,
       b.title,
       b.author,
       l.loan_date,
       l.due_date,
       l.return_date,
       l.status,
       DATEDIFF(COALESCE(l.return_date, CURDATE()), l.loan_date) AS days_borrowed,
       GREATEST(DATEDIFF(CURDATE(), l.due_date), 0) AS days_overdue
FROM loans l
JOIN books b ON l.book_id = b.book_id
JOIN members m ON l.member_id = m.member_id
WHERE m.member_id = 123
ORDER BY l.loan_date DESC;

-- ============================================
-- TRIGGERS FOR BOOK AVAILABILITY MANAGEMENT
-- ============================================

-- Trigger: Decrease available_copies and set is_available to FALSE when a book is borrowed
DELIMITER //
CREATE TRIGGER decrease_book_availability
AFTER INSERT ON loans
FOR EACH ROW
BEGIN
    -- Only decrease if the loan status is 'Active'
    IF NEW.status = 'Active' THEN
        UPDATE books
        SET available_copies = available_copies - 1,
            is_available = CASE 
                WHEN (available_copies - 1) > 0 THEN TRUE 
                ELSE FALSE 
            END
        WHERE book_id = NEW.book_id
        AND available_copies > 0;
    END IF;
END//
DELIMITER ;

-- Trigger: Increase available_copies and set is_available to TRUE when a book is returned
DELIMITER //
CREATE TRIGGER increase_book_availability
AFTER UPDATE ON loans
FOR EACH ROW
BEGIN
    -- If status changed from 'Active' or 'Overdue' to 'Returned'
    IF OLD.status IN ('Active', 'Overdue') AND NEW.status = 'Returned' THEN
        UPDATE books
        SET available_copies = available_copies + 1,
            is_available = TRUE
        WHERE book_id = NEW.book_id
        AND available_copies < total_copies;
    END IF;
END//
DELIMITER ;

-- ============================================
-- STORED PROCEDURE FOR SAFE MEMBER DELETION
-- ============================================

-- Stored Procedure: Safely delete a member record
-- This procedure checks for active loans before deletion
DELIMITER //
CREATE PROCEDURE delete_member_safely(IN p_member_id INT)
BEGIN
    DECLARE active_loans_count INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Check if member exists
    IF NOT EXISTS (SELECT 1 FROM members WHERE member_id = p_member_id) THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Member does not exist';
    END IF;
    
    -- Count active loans for this member
    SELECT COUNT(*) INTO active_loans_count
    FROM loans
    WHERE member_id = p_member_id
    AND status IN ('Active', 'Overdue');
    
    -- If member has active loans, prevent deletion
    IF active_loans_count > 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = CONCAT('Cannot delete member: Member has ', active_loans_count, ' active or overdue loan(s). Please return all books first.');
    ELSE
        -- Safe to delete: Member has no active loans
        DELETE FROM members WHERE member_id = p_member_id;
        
        COMMIT;
        SELECT CONCAT('Member ID ', p_member_id, ' has been safely deleted.') AS result;
    END IF;
END//
DELIMITER ;

