# PowerShell script to run the SQL file
# Make sure MySQL is installed and update the path below

# Common MySQL installation paths on Windows:
# "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
# "C:\xampp\mysql\bin\mysql.exe"
# "C:\wamp64\bin\mysql\mysql8.0.xx\bin\mysql.exe"

$mysqlPath = "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe"
$sqlFile = "task.sql"
$username = "root"
$password = Read-Host "Enter MySQL password" -AsSecureString
$plainPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($password))

if (Test-Path $mysqlPath) {
    & $mysqlPath -u $username -p$plainPassword < $sqlFile
    Write-Host "SQL script executed successfully!"
} else {
    Write-Host "MySQL not found at: $mysqlPath"
    Write-Host "Please update the mysqlPath variable in this script with your MySQL installation path"
}

