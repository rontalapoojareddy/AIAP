# How to Run the SQL Script

This guide explains different ways to execute the `task.sql` file.

## Prerequisites
- MySQL Server must be installed on your system
- You need MySQL root password (or credentials for a MySQL user with appropriate privileges)

---

## Method 1: MySQL Command Line (Recommended)

### Step 1: Find your MySQL installation path
Common locations:
- `C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe`
- `C:\xampp\mysql\bin\mysql.exe`
- `C:\wamp64\bin\mysql\mysql8.0.xx\bin\mysql.exe`

### Step 2: Open Command Prompt or PowerShell
Navigate to this directory:
```powershell
cd "C:\Users\anred\OneDrive\Desktop\AIAP\Assignments\Assignment16"
```

### Step 3: Run the command
Replace the path with your MySQL installation path:
```powershell
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p < task.sql
```

You'll be prompted to enter your MySQL password.

**Alternative (if MySQL is in PATH):**
```powershell
mysql -u root -p < task.sql
```

---

## Method 2: Using MySQL Workbench (GUI - Easiest)

1. **Open MySQL Workbench**
2. **Connect to your MySQL server** (enter your password)
3. **File → Open SQL Script** → Select `task.sql`
4. **Click the Execute button** (lightning bolt icon) or press `Ctrl+Shift+Enter`
5. The script will run and show results in the output panel

---

## Method 3: Using the Batch File (Windows)

1. **Edit `run_sql.bat`** and update the MySQL path
2. **Double-click `run_sql.bat`**
3. Enter your MySQL password when prompted

---

## Method 4: Using PowerShell Script

1. **Edit `run_sql.ps1`** and update the `$mysqlPath` variable
2. **Open PowerShell** in this directory
3. **Run:**
   ```powershell
   .\run_sql.ps1
   ```
4. Enter your MySQL password when prompted

**Note:** If you get an execution policy error, run:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Method 5: Using phpMyAdmin (if using XAMPP/WAMP)

1. **Start XAMPP/WAMP** and ensure MySQL is running
2. **Open phpMyAdmin** in your browser (usually `http://localhost/phpmyadmin`)
3. **Click on "Import" tab**
4. **Choose File** → Select `task.sql`
5. **Click "Go"** to execute

---

## Method 6: Direct MySQL Command (Interactive)

1. **Open Command Prompt/PowerShell**
2. **Connect to MySQL:**
   ```powershell
   "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p
   ```
3. **Once connected, run:**
   ```sql
   source task.sql;
   ```
   Or:
   ```sql
   \. task.sql
   ```

---

## What the Script Does

The script will:
1. Drop and recreate the `library_management` database
2. Create tables (books, members, loans)
3. Insert sample data
4. Create views
5. Create triggers for automatic book availability updates
6. Create a stored procedure for safe member deletion

---

## Testing the Features

After running the script, you can test:

### Test Book Availability Update:
```sql
-- Check current availability
SELECT book_id, title, available_copies, is_available FROM books WHERE book_id = 1;

-- Create a new loan (this will trigger availability update)
INSERT INTO loans (book_id, member_id, loan_date, due_date, status) 
VALUES (1, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Active');

-- Check availability again (should be updated)
SELECT book_id, title, available_copies, is_available FROM books WHERE book_id = 1;
```

### Test Safe Member Deletion:
```sql
-- Try to delete a member with active loans (should fail)
CALL delete_member_safely(2);

-- Return all books for a member first
UPDATE loans SET status = 'Returned', return_date = CURDATE() WHERE member_id = 2 AND status = 'Active';

-- Now try to delete (should succeed)
CALL delete_member_safely(2);
```

---

## Troubleshooting

**Error: "mysql: command not found"**
- MySQL is not in your system PATH
- Use the full path to mysql.exe (Method 1)

**Error: "Access denied"**
- Check your MySQL username and password
- Ensure the user has CREATE DATABASE privileges

**Error: "Unknown database"**
- The script creates the database, so this shouldn't happen
- Make sure you're running the entire script

**Error: "Table already exists"**
- The script uses `DROP DATABASE IF EXISTS`, so this shouldn't happen
- If it does, manually drop the database first:
  ```sql
  DROP DATABASE IF EXISTS library_management;
  ```

---

## Need Help?

If you encounter issues:
1. Check that MySQL Server is running
2. Verify your MySQL installation path
3. Ensure you have the correct credentials
4. Check MySQL error logs for detailed error messages

