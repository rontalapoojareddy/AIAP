# TGNPDCL Electricity Bill Calculator
# Author: R.Pooja Reddy
# ID: 2503B05130

def calculate_electricity_bill():
    print("\n===== TGNPDCL Electricity Bill Calculator =====\n")
    
    try:
        # Get meter readings
        previous_reading = float(input("Enter Previous Month Reading: "))
        current_reading = float(input("Enter Current Month Reading: "))
        
        # Input validation for readings
        if current_reading < previous_reading:
            print("Error: Current reading cannot be less than previous reading!")
            return
        
        # Calculate units consumed
        units = current_reading - previous_reading
        
        # Get customer type
        print("\nCustomer Types Available:")
        print("1. Domestic")
        print("2. Commercial")
        print("3. Industrial")
        choice = input("\nSelect Customer Type (1/2/3): ")
        
        # Initialize bill components
        energy_charge = 0
        fixed_charge = 0
        meter_rent = 0
        tax_percent = 0
        
        # Set tariff based on customer type
        if choice == "1":  # Domestic
            customer_type = "Domestic"
            fixed_charge = 50
            meter_rent = 15
            tax_percent = 5
            
            # Slab-wise calculation for domestic
            if units <= 100:
                energy_charge = units * 3.50
            elif units <= 200:
                energy_charge = (100 * 3.50) + ((units - 100) * 4.50)
            else:
                energy_charge = (100 * 3.50) + (100 * 4.50) + ((units - 200) * 6.00)
                
        elif choice == "2":  # Commercial
            customer_type = "Commercial"
            fixed_charge = 150
            meter_rent = 25
            tax_percent = 10
            energy_charge = units * 8.50
            
        elif choice == "3":  # Industrial
            customer_type = "Industrial"
            fixed_charge = 300
            meter_rent = 50
            tax_percent = 12
            energy_charge = units * 10.00
            
        else:
            print("Invalid choice! Please select 1, 2, or 3")
            return
        
        # Calculate tax and total
        subtotal = energy_charge + fixed_charge + meter_rent
        tax = (subtotal * tax_percent) / 100
        total_bill = subtotal + tax
        
        # Print the bill
        print("\n========= ELECTRICITY BILL =========")
        print(f"Customer Type        : {customer_type}")
        print(f"Previous Reading     : {previous_reading:.1f}")
        print(f"Current Reading      : {current_reading:.1f}")
        print(f"Units Consumed       : {units:.1f}")
        print("---------------------------------")
        print(f"Energy Charges       : ₹{energy_charge:.2f}")
        print(f"Fixed Charges        : ₹{fixed_charge:.2f}")
        print(f"Meter Rent           : ₹{meter_rent:.2f}")
        print(f"Tax ({tax_percent}%)         : ₹{tax:.2f}")
        print("=================================")
        print(f"Total Bill Amount    : ₹{total_bill:.2f}")
        print("=================================")
        
        # Add energy saving tip based on consumption
        if units > 200:
            print("\nTip: Your consumption is high.")
            print("Consider using energy-efficient appliances")
            print("and LED bulbs to reduce your bill.")
            
    except ValueError:
        print("Error: Please enter valid numerical values for readings!")

# Main program
if __name__ == "__main__":
    while True:
        calculate_electricity_bill()
        choice = input("\nCalculate another bill? (yes/no): ").lower()
        if choice != 'yes':
            print("\nThank you for using TGNPDCL Bill Calculator!")
            break