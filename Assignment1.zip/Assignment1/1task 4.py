# ...existing code...
# Recursive factorial function
def factorial_recursive(n: int) -> int:
    """Return n! for n >= 0. Raises ValueError for negative inputs."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")
    return 1 if n <= 1 else n * factorial_recursive(n - 1)

# Iterative factorial function
def factorial_iterative(n: int) -> int:
    """Return n! for n >= 0. Raises ValueError for negative inputs."""
    if not isinstance(n, int):
        raise TypeError("n must be an integer")
    if n < 0:
        raise ValueError("n must be non-negative")
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
# ...existing code...

if __name__ == "__main__":
    print("Choose mode: 'i' = iterative, 'f' = recursive, 'b' = both. Type 'q' to quit.")
    while True:
        mode = input("Mode (i/f/b) or 'q' to quit: ").strip().lower()
        if mode == "q":
            print("Exiting.")
            break
        # allow combinations like "if" or "fi" to mean both
        if mode not in ("i", "f", "b") and not set(mode).issubset(set("if")):
            print("Invalid selection. Enter 'i', 'f', 'b', or 'q'.")
            continue

        s = input("Enter a non-negative integer (or 'q' to quit): ").strip()
        if s.lower() == "q":
            print("Exiting.")
            break
        try:
            n = int(s)
            if n < 0:
                print("Please enter a non-negative integer.")
                continue
        except ValueError:
            print("Invalid integer.")
            continue

        do_iter = "i" in mode or mode == "b"
        do_rec = "f" in mode or mode == "b" or ("f" in set(mode))

        if do_iter:
            try:
                print(f"Iterative: {n}! = {factorial_iterative(n)}")
            except Exception as e:
                print("Iterative error:", e)

        if do_rec:
            try:
                print(f"Recursive: {n}! = {factorial_recursive(n)}")
            except RecursionError:
                print("Recursive error: recursion depth exceeded.")
            except Exception as e:
                print("Recursive error:", e)
# ...existing code...