# ...existing code...
# Function to reverse a string
def reverse_string(s: str) -> str:
    """Return a new string which is the reverse of s."""
    return s[::-1]

if __name__ == "__main__":
    while True:
        s = input("Enter a string to reverse (or 'q' to quit): ").strip()
        if s.lower() == "q":
            print("Exiting.")
            break
        print(reverse_string(s))
# ...existing code...