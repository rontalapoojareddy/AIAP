# ...existing code...
from typing import Iterable, TypeVar

T = TypeVar("T")

def copilot_find_max(lst: Iterable[T]) -> T:
    """Return the largest element in lst. Raises ValueError on empty input."""
    iterator = iter(lst)
    try:
        max_val = next(iterator)
    except StopIteration:
        raise ValueError("copilot_find_max() arg is an empty iterable")
    for item in iterator:
        if item > max_val:
            max_val = item
    return max_val

def copilot_find_max_builtin(lst: Iterable[T]) -> T:
    """Wrapper around built-in max() with the same behaviour/complexity."""
    try:
        return max(lst)
    except ValueError:
        raise ValueError("copilot_find_max_builtin() arg is an empty iterable")
# ...existing code...

# ...existing code...
if __name__ == "__main__":
    print("Enter numbers separated by spaces. Type 'q' to quit.")
    while True:
        s = input("Numbers (or 'q'): ").strip()
        if s.lower() in ("q", "quit"):
            print("Exiting.")
            break
        parts = s.split()
        if not parts:
            print("No input provided.")
            continue
        try:
            nums = [float(p) for p in parts]
        except ValueError:
            print("Invalid input: enter numbers separated by spaces.")
            continue
        try:
            print("Largest number:", copilot_find_max(nums))
        except ValueError as e:
            print("Error:", e)
# ...existing code...