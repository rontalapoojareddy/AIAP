from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

@app.route('/')
def index():
    """Serve the login form"""
    return render_template('task3.html')

@app.route('/login', methods=['POST'])
def login():
    """Handle login form submission"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    # Validate that both fields are non-empty
    if not username or not password:
        return jsonify({'success': False, 'message': 'Username and password cannot be empty.'}), 400
    
    # Print the username to console on successful login
    print(f"User logged in: {username}")
    # Return username and credentials info
    credentials_info = 'k'
    return jsonify({
        'success': True,
        'message': f'Welcome, {username}! Your credentials are {credentials_info}',
        'username': username,
        'credentials': credentials_info
    }), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)
