import sys
import subprocess
import time
import threading
import webbrowser

def install(pkgs):
    subprocess.check_call([sys.executable, "-m", "pip", "install"] + pkgs)

try:
    # Try import to check if installed
    import flask  # noqa: F401
except Exception:
    print("Installing Flask and Werkzeug...")
    install(["Flask==2.0.3", "Werkzeug==2.0.3"])

from app import app

def run_server():
    # Use use_reloader=False so we can run in a background thread safely
    app.run(host='127.0.0.1', port=5000, debug=False, use_reloader=False)

def wait_for_server(url, timeout=10.0):
    import urllib.request
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.2)
    return False

if __name__ == '__main__':
    url = 'http://127.0.0.1:5000/'
    thread = threading.Thread(target=run_server, daemon=True)
    thread.start()

    ok = wait_for_server(url, timeout=10.0)
    if not ok:
        print('Server did not start within timeout. Check the console for errors.')
        # Keep process alive to let user see errors
        thread.join()
    else:
        print('Server started — opening browser at', url)
        try:
            webbrowser.open(url)
        except Exception:
            print('Could not open browser automatically — open', url, 'manually')
        # Keep main thread alive while server thread runs
        try:
            thread.join()
        except KeyboardInterrupt:
            print('Shutting down.')
