from typing import List, Tuple


def is_valid_email(email: str) -> bool:
    """
    Basic email validator that satisfies the given requirements:
      - Must contain exactly one '@'
      - Must contain a '.' after the '@' (overall must contain '.' as well)
      - Must not start or end with special characters (only allow alphanumeric at ends)
      - Should not allow multiple '@'
    Additional pragmatic checks:
      - No whitespace characters
      - Local and domain parts must be non-empty
      - Domain labels must not be empty (no consecutive dots in domain)
    """
    if not isinstance(email, str):
        return False
    if not email:
        return False
    if email[0].isalnum() is False or email[-1].isalnum() is False:
        return False
    if " " in email or "\t" in email or "\n" in email or "\r" in email:
        return False

    if email.count("@") != 1:
        return False
    local_part, domain_part = email.split("@", 1)
    if not local_part or not domain_part:
        return False

    # Must contain a dot after '@'
    if "." not in domain_part:
        return False

    # Prevent empty domain labels (e.g., "example..com" or ".example.com")
    domain_labels = domain_part.split(".")
    if any(label == "" for label in domain_labels):
        return False

    return True


def generate_test_cases() -> Tuple[List[str], List[str]]:
    """AI-generated diverse valid/invalid email samples based on the requirements."""
    valid = [
        "user@example.com",
        "username@domain.co",
        "john.doe@sub.domain.com",
        "u1@d.io",
        "alice123@service.org",
        "first_last@dept.company.net",
        "a.b-c_d@multi.part-domain.com",
    ]
    invalid = [
        "",  # empty
        "userexample.com",  # missing @
        "user@@example.com",  # multiple @
        ".user@example.com",  # starts with special
        "user@example.com.",  # ends with special
        "user@domain",  # no dot after @
        "user@.domain.com",  # empty domain label
        "user@domain..com",  # consecutive dots in domain
        " user@example.com",  # leading space
        "user@example.com ",  # trailing space
        "user.\n@example.com",  # newline
        "user@example,com",  # comma instead of dot
        "user@exa mple.com",  # space inside
        "user.example@com",  # dot not in domain part
    ]
    return valid, invalid


def run_tests() -> None:
    valid, invalid = generate_test_cases()
    total = 0
    passed = 0

    for e in valid:
        total += 1
        if is_valid_email(e):
            passed += 1
        else:
            print(f"FAIL (expected valid): {e}")

    for e in invalid:
        total += 1
        if not is_valid_email(e):
            passed += 1
        else:
            print(f"FAIL (expected invalid): {e}")

    print(f"Passed {passed}/{total} tests")


if __name__ == "__main__":
    run_tests()

