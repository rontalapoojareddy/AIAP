from typing import Dict, List, Tuple, Any


class ShoppingCart:
    """
    Simple shopping cart that supports:
      - add_item(name, price): adds one unit of an item
      - remove_item(name): removes one unit, if present; raises if not found
      - total_cost(): sum of prices of all items
    Rules:
      - name must be a non-empty string
      - price must be a non-negative finite number
      - Multiple adds of the same name create multiple entries; remove removes one entry at a time
    """
    def __init__(self) -> None:
        self._items: List[Tuple[str, float]] = []

    def add_item(self, name: str, price: float) -> None:
        if not isinstance(name, str) or name.strip() == "":
            raise ValueError("Item name must be a non-empty string.")
        # Reject bool (subclass of int) and enforce number
        if isinstance(price, bool) or not isinstance(price, (int, float)):
            raise ValueError("Price must be a number.")
        # Finite and non-negative
        price_f = float(price)
        if price_f != price_f or price_f in (float("inf"), -float("inf")):
            raise ValueError("Price must be finite.")
        if price_f < 0:
            raise ValueError("Price must be non-negative.")
        self._items.append((name, price_f))

    def remove_item(self, name: str) -> None:
        if not isinstance(name, str) or name.strip() == "":
            raise ValueError("Item name must be a non-empty string.")
        for idx, (n, _) in enumerate(self._items):
            if n == name:
                del self._items[idx]
                return
        raise KeyError(f"Item not found: {name}")

    def total_cost(self) -> float:
        return sum(price for _, price in self._items)

    def __len__(self) -> int:
        return len(self._items)


def generate_test_cases() -> Dict[str, Any]:
    """
    AI-generated test scenarios:
      - add basics, remove basics, totals
      - duplicates handling
      - removing non-existent items
      - invalid inputs (name, price)
      - boundary values (0 price)
    """
    cases: Dict[str, Any] = {
        "add_and_total": {
            "steps": [
                ("add", ("apple", 1.25)),
                ("add", ("banana", 0.75)),
            ],
            "expect_len": 2,
            "expect_total": 2.0,
        },
        "duplicates_and_remove_one": {
            "steps": [
                ("add", ("apple", 1.25)),
                ("add", ("apple", 1.25)),
                ("add", ("apple", 1.25)),
                ("remove", ("apple",)),
            ],
            "expect_len": 2,
            "expect_total": 2.5,
        },
        "remove_nonexistent_should_raise": {
            "steps": [
                ("add", ("milk", 2.5)),
                ("remove", ("bread",)),  # not present
            ],
            "expect_exception": KeyError,
        },
        "invalid_name_inputs": {
            "steps": [
                ("add", ("", 1.0)),
            ],
            "expect_exception": ValueError,
        },
        "invalid_price_inputs": {
            "steps": [
                ("add", ("item", -1)),
            ],
            "expect_exception": ValueError,
        },
        "non_numeric_price": {
            "steps": [
                ("add", ("item", "10")),  # wrong type
            ],
            "expect_exception": ValueError,
        },
        "bool_price_rejected": {
            "steps": [
                ("add", ("flag", True)),
            ],
            "expect_exception": ValueError,
        },
        "zero_price_boundary": {
            "steps": [
                ("add", ("freebie", 0.0)),
            ],
            "expect_len": 1,
            "expect_total": 0.0,
        },
        "float_precision": {
            "steps": [
                ("add", ("x", 0.1)),
                ("add", ("y", 0.2)),
            ],
            "expect_len": 2,
            "expect_total": 0.30000000000000004,  # native float behavior
        },
        "remove_until_empty": {
            "steps": [
                ("add", ("a", 1)),
                ("add", ("b", 2)),
                ("remove", ("a",)),
                ("remove", ("b",)),
            ],
            "expect_len": 0,
            "expect_total": 0.0,
        },
        "invalid_remove_name": {
            "steps": [
                ("add", ("ok", 1)),
                ("remove", ("",)),
            ],
            "expect_exception": ValueError,
        },
    }
    return cases


def run_tests() -> None:
    cases = generate_test_cases()
    total = 0
    passed = 0

    for name, spec in cases.items():
        total += 1
        cart = ShoppingCart()
        try:
            for action, args in spec["steps"]:
                if action == "add":
                    cart.add_item(*args)  # type: ignore[misc]
                elif action == "remove":
                    cart.remove_item(*args)  # type: ignore[misc]
                else:
                    raise RuntimeError(f"Unknown action: {action}")

            # If an exception was expected but none raised
            if "expect_exception" in spec:
                print(f"FAIL {name}: expected exception {spec['expect_exception'].__name__} not raised")
                continue

            # Validate expectations
            expect_len = spec.get("expect_len", len(cart))
            expect_total = spec.get("expect_total", cart.total_cost())
            got_len = len(cart)
            got_total = cart.total_cost()

            if got_len == expect_len and got_total == expect_total:
                passed += 1
            else:
                print(f"FAIL {name}: expect_len={expect_len}, got_len={got_len}, "
                      f"expect_total={expect_total}, got_total={got_total}")
        except Exception as ex:
            if "expect_exception" in spec and isinstance(ex, spec["expect_exception"]):
                passed += 1
            else:
                print(f"FAIL {name}: unexpected exception: {ex}")

    print(f"Passed {passed}/{total} tests")


if __name__ == "__main__":
    run_tests()

