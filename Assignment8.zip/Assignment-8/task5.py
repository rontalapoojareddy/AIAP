from typing import List, Tuple, Any


def convert_date_format(date_str: str) -> str:
    """
    Convert date from 'YYYY-MM-DD' to 'DD-MM-YYYY'.
    Performs basic validation on structure and numeric ranges.
    """
    if not isinstance(date_str, str):
        raise ValueError("date_str must be a string")
    parts = date_str.split("-")
    if len(parts) != 3:
        raise ValueError("Invalid date format")
    year, month, day = parts
    if not (len(year) == 4 and len(month) == 2 and len(day) == 2):
        raise ValueError("Invalid date component lengths")
    if not (year.isdigit() and month.isdigit() and day.isdigit()):
        raise ValueError("Date components must be numeric")

    y = int(year)
    m = int(month)
    d = int(day)

    # Basic range checks (not full calendar validation like leap years)
    if y < 1:
        raise ValueError("Year out of range")
    if m < 1 or m > 12:
        raise ValueError("Month out of range")
    if d < 1 or d > 31:
        raise ValueError("Day out of range")

    return f"{day}-{month}-{year}"


def generate_test_cases() -> Tuple[List[Tuple[str, str]], List[Any]]:
    """
    AI-generated test cases for date format conversion.
      - valid_cases: (input, expected_output)
      - invalid_inputs: inputs that should raise ValueError
    """
    valid_cases: List[Tuple[str, str]] = [
        ("2023-10-15", "15-10-2023"),  # example
        ("1999-01-01", "01-01-1999"),
        ("0001-12-31", "31-12-0001"),
        ("2020-02-29", "29-02-2020"),  # not enforcing leap year validity here
        ("2010-09-07", "07-09-2010"),
    ]

    invalid_inputs: List[Any] = [
        "2023/10/15",     # wrong delimiter
        "23-10-15",       # wrong year length
        "2023-1-05",      # wrong month length
        "2023-01-5",      # wrong day length
        "2023-13-01",     # month out of range
        "2023-00-10",     # month zero
        "2023-10-32",     # day out of range
        "2023-10-00",     # day zero
        "abcd-10-15",     # non-numeric year
        "2023-1a-15",     # non-numeric month
        "2023-10-1b",     # non-numeric day
        "2023-10",        # missing component
        "",               # empty
        None,             # non-string
        True,             # non-string
        ["2023-10-15"],   # wrong type
    ]
    return valid_cases, invalid_inputs


def run_tests() -> None:
    valid_cases, invalid_inputs = generate_test_cases()
    total = 0
    passed = 0

    for inp, expected in valid_cases:
        total += 1
        try:
            out = convert_date_format(inp)
            if out == expected:
                passed += 1
            else:
                print(f"FAIL valid: input={inp!r}, expected={expected!r}, got={out!r}")
        except Exception as ex:
            print(f"FAIL valid raised: input={inp!r}, ex={ex}")

    for value in invalid_inputs:
        total += 1
        try:
            _ = convert_date_format(value)  # type: ignore[arg-type]
            print(f"FAIL invalid: input={value!r}, expected=ValueError, got=return")
        except ValueError:
            passed += 1
        except Exception as ex:
            print(f"FAIL invalid wrong exception: input={value!r}, ex={ex}")

    print(f"Passed {passed}/{total} tests")


if __name__ == "__main__":
    run_tests()

