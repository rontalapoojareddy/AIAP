from typing import Any, List, Tuple, Union
import math


def assign_grade(score: Union[int, float]) -> str:
    """
    Returns a letter grade for the given score according to:
      90-100: A, 80-89: B, 70-79: C, 60-69: D, <60: F

    Validation:
      - Accepts int or float (bool is rejected).
      - Must be finite (not NaN/Inf).
      - Must be within [0, 100]. Otherwise raises ValueError.
    """
    # Reject non-number types and bool explicitly (bool is subclass of int)
    if isinstance(score, bool) or not isinstance(score, (int, float)):
        raise ValueError("Score must be a number.")
    if not math.isfinite(float(score)):
        raise ValueError("Score must be a finite number.")

    if score < 0 or score > 100:
        raise ValueError("Score must be between 0 and 100 inclusive.")

    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


def generate_test_cases() -> Tuple[List[Tuple[Any, str]], List[Any]]:
    """
    AI-generated tests:
      - valid_cases: list of (input, expected_grade)
      - invalid_cases: inputs that should raise ValueError
    Includes boundary and representative interior values.
    """
    valid_cases: List[Tuple[Any, str]] = [
        # Boundaries and near-boundaries
        (100, "A"),
        (99.9, "A"),
        (90, "A"),
        (89.999, "B"),
        (89, "B"),
        (80, "B"),
        (79.999, "C"),
        (79, "C"),
        (70, "C"),
        (69.999, "D"),
        (69, "D"),
        (60, "D"),
        (59.999, "F"),
        (0, "F"),
        (42, "F"),
        # Additional typical values
        (95, "A"),
        (85, "B"),
        (75, "C"),
        (65, "D"),
        (10, "F"),
    ]

    invalid_cases: List[Any] = [
        -5,          # below range
        105,         # above range
        "eighty",    # non-numeric string
        None,        # None input
        True,        # bool should be rejected
        float("nan"),
        float("inf"),
        -float("inf"),
        {},          # wrong type
        [],          # wrong type
    ]
    return valid_cases, invalid_cases


def run_tests() -> None:
    valid_cases, invalid_cases = generate_test_cases()
    total = 0
    passed = 0

    # Valid cases
    for value, expected in valid_cases:
        total += 1
        try:
            result = assign_grade(value)
            if result == expected:
                passed += 1
            else:
                print(f"FAIL valid: input={value!r}, expected={expected!r}, got={result!r}")
        except Exception as ex:
            print(f"FAIL valid raised: input={value!r}, expected={expected!r}, ex={ex}")

    # Invalid cases
    for value in invalid_cases:
        total += 1
        try:
            _ = assign_grade(value)
            print(f"FAIL invalid: input={value!r}, expected=ValueError, got=return")
        except ValueError:
            passed += 1
        except Exception as ex:
            print(f"FAIL invalid wrong exception: input={value!r}, ex={ex}")

    print(f"Passed {passed}/{total} tests")


if __name__ == "__main__":
    run_tests()

