from typing import List, Tuple, Any
import string


def is_sentence_palindrome(sentence: str) -> bool:
    """
    Returns True if sentence is a palindrome when ignoring case, spaces, and punctuation.
    Keeps only alphanumeric characters and compares case-insensitively.
    """
    if not isinstance(sentence, str):
        return False
    # Normalize: keep only alphanumeric, lowercase
    normalized_chars = [ch.lower() for ch in sentence if ch.isalnum()]
    return normalized_chars == list(reversed(normalized_chars))


def generate_test_cases() -> Tuple[List[Tuple[str, bool]], List[Any]]:
    """
    AI-generated test cases for sentence palindrome validator.
      - Each valid_case: (input_sentence, expected_boolean)
      - invalid_inputs: non-string values that should result in False
    """
    valid_cases: List[Tuple[str, bool]] = [
        # Provided example
        ("A man a plan a canal Panama", True),
        # Simple palindromes with punctuation and mixed case
        ("Madam, I'm Adam.", True),
        ("Was it a car or a cat I saw?", True),
        ("No 'x' in Nixon", True),
        ("Able was I, ere I saw Elba!", True),
        ("Never odd or even", True),
        ("Do geese see God?", True),
        ("Racecar", True),
        ("", True),  # empty is trivially palindrome
        ("   ", True),  # spaces only
        (".,!?", True),  # punctuation only
        # Non-palindromes
        ("Hello, World!", False),
        ("This is not a palindrome.", False),
        ("Palindrome emordnilaP?", True),  # symmetric when ignoring punctuation and case
        ("12321", True),  # numeric palindrome
        ("12345", False),
        ("1a2", False),
        ("Red rum, sir, is murder", True),
        ("Step on no pets", True),
        ("Top spot", True),
        ("Eva, can I see bees in a cave?", True),
    ]

    invalid_inputs: List[Any] = [
        None,
        123,
        12.34,
        True,
        ["not", "a", "string"],
        {"s": "string"},
    ]
    return valid_cases, invalid_inputs


def run_tests() -> None:
    valid_cases, invalid_inputs = generate_test_cases()
    total = 0
    passed = 0

    for sentence, expected in valid_cases:
        total += 1
        try:
            result = is_sentence_palindrome(sentence)
            if result == expected:
                passed += 1
            else:
                print(f"FAIL valid: input={sentence!r}, expected={expected!r}, got={result!r}")
        except Exception as ex:
            print(f"FAIL valid raised: input={sentence!r}, ex={ex}")

    for value in invalid_inputs:
        total += 1
        try:
            result = is_sentence_palindrome(value)  # type: ignore[arg-type]
            if result is False:
                passed += 1
            else:
                print(f"FAIL invalid: input={value!r}, expected=False, got={result!r}")
        except Exception as ex:
            print(f"FAIL invalid raised: input={value!r}, ex={ex}")

    print(f"Passed {passed}/{total} tests")


if __name__ == "__main__":
    run_tests()

