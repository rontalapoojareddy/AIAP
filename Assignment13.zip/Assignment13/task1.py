import math
def calculate_area(shape, x, y=None):
    """
    Calculate area of a rectangle, square, or circle.

    - shape: "rectangle", "square", or "circle"
    - x: for rectangle → length, for square/circle → side/radius
    - y: for rectangle → width (required), ignored for others
    """
    shape = shape.lower()

    if shape == "rectangle":
        if y is None:
            raise ValueError("Rectangle area requires both x and y (length and width).")
        return x * y

    if shape == "square":
        return x * x

    if shape == "circle":
        return math.pi * x * x

    raise ValueError(f"Unknown shape: {shape}")


if __name__ == "__main__":
    print("Rectangle 3 x 4:", calculate_area("rectangle", 3, 4))
    print("Square side 5:", calculate_area("square", 5))
    print("Circle radius 2:", calculate_area("circle", 2))