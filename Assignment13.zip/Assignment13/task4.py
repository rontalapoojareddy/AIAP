def squares_list_comprehension(numbers):
    """
    Create a list of squares from a list of numbers using list comprehension.
    
    This is the most Pythonic and efficient way to create a new list by
    transforming elements from an existing list.
    
    Args:
        numbers (list): A list of numbers to square
        
    Returns:
        list: A new list containing the squares of all numbers in the input list
        
    Example:
        >>> nums = [1, 2, 3, 4, 5]
        >>> result = squares_list_comprehension(nums)
        >>> print(result)
        [1, 4, 9, 16, 25]
    """
    return [num * num for num in numbers]


def squares_map_function(numbers):
    """
    Create a list of squares from a list of numbers using the map function.
    
    This is a functional programming approach to transforming list elements.
    
    Args:
        numbers (list): A list of numbers to square
        
    Returns:
        list: A new list containing the squares of all numbers in the input list
        
    Example:
        >>> nums = [1, 2, 3, 4, 5]
        >>> result = squares_map_function(nums)
        >>> print(result)
        [1, 4, 9, 16, 25]
    """
    return list(map(lambda x: x * x, numbers))


def squares_loop_original(numbers):
    """
    Original inefficient loop approach (shown for comparison).
    
    This method uses a traditional for loop with append, which is less
    efficient and less Pythonic than list comprehension or map.
    
    Args:
        numbers (list): A list of numbers to square
        
    Returns:
        list: A new list containing the squares of all numbers in the input list
    """
    squares = []
    for i in numbers:
        squares.append(i * i)
    return squares


# Example usage and testing:
if __name__ == "__main__":
    # Original list
    nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    print("Original list:", nums)
    print()
    
    # Method 1: List Comprehension (Recommended - Most Pythonic)
    print("=" * 50)
    print("Method 1: List Comprehension (Recommended)")
    print("=" * 50)
    squares1 = squares_list_comprehension(nums)
    print("Squares:", squares1)
    print("Code: [num * num for num in nums]")
    print()
    
    # Method 2: Map Function (Functional Approach)
    print("=" * 50)
    print("Method 2: Map Function (Functional Approach)")
    print("=" * 50)
    squares2 = squares_map_function(nums)
    print("Squares:", squares2)
    print("Code: list(map(lambda x: x * x, nums))")
    print()
    
    # Method 3: Original Loop (For Comparison)
    print("=" * 50)
    print("Method 3: Original Loop (For Comparison)")
    print("=" * 50)
    squares3 = squares_loop_original(nums)
    print("Squares:", squares3)
    print("Code: Traditional for loop with append")
    print()
    
    # Verify all methods produce the same result
    print("=" * 50)
    print("Verification:")
    print("=" * 50)
    print(f"All methods produce same result: {squares1 == squares2 == squares3}")
    print()
    
    # Performance comparison note
    print("=" * 50)
    print("Performance Notes:")
    print("=" * 50)
    print("List comprehension is generally:")
    print("- More readable and Pythonic")
    print("- Faster than loop with append")
    print("- Preferred for simple transformations")
    print()
    print("Map function is:")
    print("- Good for functional programming style")
    print("- Similar performance to list comprehension")
    print("- Less readable for simple cases")
    print()
    print("Original loop with append:")
    print("- More verbose")
    print("- Slower due to repeated append calls")
    print("- Less Pythonic")
    print()
    
    # Additional example with different input
    print("=" * 50)
    print("Additional Example:")
    print("=" * 50)
    test_nums = [2, 4, 6, 8, 10]
    print(f"Input: {test_nums}")
    print(f"Squares: {squares_list_comprehension(test_nums)}")

