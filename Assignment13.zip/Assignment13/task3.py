class Student:
    """
    A class to represent a student with personal information and marks.
    
    This class stores a student's name, age, and three marks, and provides
    methods to display student details and calculate total marks.
    """
    
    def __init__(self, name, age, mark1, mark2, mark3):
        """
        Initialize a Student instance with personal information and marks.
        
        Args:
            name (str): The name of the student
            age (int): The age of the student
            mark1 (float): First mark/score
            mark2 (float): Second mark/score
            mark3 (float): Third mark/score
            
        Raises:
            ValueError: If age is negative or marks are invalid
        """
        if age < 0:
            raise ValueError(f"Age cannot be negative. Got: {age}")
        if mark1 < 0 or mark2 < 0 or mark3 < 0:
            raise ValueError("Marks cannot be negative.")
        
        self.name = name
        self.age = age
        self.mark1 = mark1
        self.mark2 = mark2
        self.mark3 = mark3
    
    def details(self):
        """
        Return a formatted string with the student's name and age.
        
        Returns:
            str: A formatted string containing the student's name and age
            
        Example:
            >>> student = Student("John", 20, 85, 90, 88)
            >>> print(student.details())
            Name: John, Age: 20
        """
        return f"Name: {self.name}, Age: {self.age}"
    
    def total(self):
        """
        Calculate and return the total of all three marks.
        
        Returns:
            float: The sum of mark1, mark2, and mark3
            
        Example:
            >>> student = Student("John", 20, 85, 90, 88)
            >>> print(student.total())
            263
        """
        return self.mark1 + self.mark2 + self.mark3
    
    def average(self):
        """
        Calculate and return the average of all three marks.
        
        Returns:
            float: The average of mark1, mark2, and mark3
            
        Example:
            >>> student = Student("John", 20, 85, 90, 88)
            >>> print(student.average())
            87.67
        """
        return self.total() / 3


# Example usage and testing:
if __name__ == "__main__":
    try:
        # Create a student instance
        student1 = Student("John Doe", 20, 85, 90, 88)
        
        # Display student details
        print("Student Details:")
        print(student1.details())
        
        # Calculate and display total marks
        total_marks = student1.total()
        print(f"\nTotal Marks: {total_marks}")
        
        # Calculate and display average marks
        avg_marks = student1.average()
        print(f"Average Marks: {avg_marks:.2f}")
        
        # Test with another student
        print("\n" + "="*40)
        student2 = Student("Jane Smith", 19, 92, 87, 95)
        print("Student Details:")
        print(student2.details())
        print(f"Total Marks: {student2.total()}")
        print(f"Average Marks: {student2.average():.2f}")
        
        # Test error handling - invalid age
        print("\n" + "="*40)
        print("Testing error handling:")
        try:
            invalid_student = Student("Test", -5, 85, 90, 88)
        except ValueError as e:
            print(f"Caught expected error: {e}")
        
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

