import math  # Import math module for pi and other mathematical operations
class ShapeCalculator:
    """A class containing methods to calculate areas of various shapes.
    Each method is documented with detailed explanations."""
    @staticmethod
    def circle_area(radius: float) -> float:
        """Calculate the area of a circle.
        Line by line explanation:
        1. Method definition with type hints:
           - @staticmethod: No need for class instance
           - (radius: float): Takes radius parameter of type float
           - -> float: Returns a float value
        2. Formula used: A = πr²
           - math.pi: Get value of π from math module
           - radius ** 2: Square the radius
        Args:
            radius (float): The radius of the circle
        Returns:
            float: The area of the circle"""
        return math.pi * (radius ** 2)
    @staticmethod
    def rectangle_area(length: float, width: float) -> float:
        """Calculate the area of a rectangle.
        Line by line explanation:
        1. Method definition:
           - Takes two parameters: length and width
           - Both parameters are type-hinted as float
           - Return type is specified as float
        2. Formula used: A = length × width
           - Simple multiplication of length and width
        Args:
            length (float): The length of the rectangle
            width (float): The width of the rectangle
        Returns:
            float: The area of the rectangle"""
        return length * width
    @staticmethod
    def triangle_area(base: float, height: float) -> float:
        """Calculate the area of a triangle.
        Line by line explanation:
        1. Method definition:
           - Parameters: base and height as floats
           - Returns: float value
        2. Formula used: A = ½ × base × height
           - Multiply base and height
           - Divide by 2 (can also write as * 0.5)
        Args:
            base (float): The base length of the triangle
            height (float): The height of the triangle
        Returns:
            float: The area of the triangle"""
        return (base * height) / 2
    @staticmethod
    def trapezoid_area(a: float, b: float, height: float) -> float:
        """Calculate the area of a trapezoid.
        Line by line explanation:
        1. Method definition:
           - Parameters: parallel sides a, b and height
           - All parameters are type-hinted as float
           - Return type is float
        2. Formula used: A = ½(a + b)h
           - Add parallel sides (a + b)
           - Multiply by height
           - Divide by 2
        Args:
            a (float): Length of one parallel side
            b (float): Length of other parallel side
            height (float): Height between parallel sides
        Returns:
            float: The area of the trapezoid"""
        return ((a + b) * height) / 2
# Example usage with detailed explanations
if __name__ == "__main__":
    # Create an instance of ShapeCalculator
    calc = ShapeCalculator()
    # Example 1: Circle Area
    radius = 5
    circle_area = calc.circle_area(radius)
    print(f"Circle (radius = {radius}):")
    print(f"Area = π × {radius}² = {circle_area:.2f}")
    print()
    
    # Example 2: Rectangle Area
    length, width = 6, 4
    rect_area = calc.rectangle_area(length, width)
    print(f"Rectangle (length = {length}, width = {width}):")
    print(f"Area = {length} × {width} = {rect_area}")
    print()

    # Example 3: Triangle Area
    base, height = 5, 3
    tri_area = calc.triangle_area(base, height)
    print(f"Triangle (base = {base}, height = {height}):")
    print(f"Area = ½ × {base} × {height} = {tri_area}")
    print()
    
    # Example 4: Trapezoid Area
    a, b, h = 6, 4, 3
    trap_area = calc.trapezoid_area(a, b, h)
    print(f"Trapezoid (a = {a}, b = {b}, height = {h}):")
    print(f"Area = ½ × ({a} + {b}) × {h} = {trap_area}")