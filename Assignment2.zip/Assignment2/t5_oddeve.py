l=[1,3,2,4,5,7,6,8]
e=o=0
for i in range(len(l)):
    if i%2==0:
        e=e+l[i]
    else:
        o=o+l[i]
print("Sum of even index elements:",e)
print("Sum of odd index elements:",o)