def is_palindrome(text):
    """Check if the given input is a palindrome.
    Args:
        text: Input to check (string or number)
    Returns:
        bool: True if input is palindrome, False otherwise
    Examples:
        is_palindrome("radar") -> True
        is_palindrome("hello") -> False
        is_palindrome(12321) -> True
        is_palindrome(12345) -> False"""
    # Convert input to string and remove spaces, punctuation
    text = str(text).lower()
    # Keep only alphanumeric characters
    cleaned = ''.join(char for char in text if char.isalnum())
    # Compare string with its reverse
    return cleaned == cleaned[::-1]
# Demo with test cases
if __name__ == "__main__":
    test_cases = [
        "radar",
        "race a car",
        12321,
        12345,
        "Was it a car or a cat I saw?",
        "hello world"
    ]
    print("Palindrome Checker Demo\n")
    for test in test_cases:
        result = is_palindrome(test)
        print(f"Input: {test}")
        print(f"Is palindrome? {result}")