"""Single-file CSV stats demo.

This script contains the CSV stats function, writes an example CSV to disk,
reads it and prints count, mean, min, max and sum for the chosen column.

Run: python single_file_demo.py
"""
from pathlib import Path
import csv
from typing import Optional, Union, Dict

Number = Union[int, float]


def _to_float(s: str) -> Optional[float]:
    s = s.strip()
    if s == "":
        return None
    if s.lower() in ("nan", "na", "null"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def read_csv_stats(file_path: str,
                   column: Optional[Union[int, str]] = None,
                   delimiter: str = ',',
                   has_header: bool = True) -> Dict[str, Number]:
    """Read CSV and compute simple statistics for a single column.

    Args:
        file_path: path to CSV file
        column: column index (int) or column name (str). If None, uses the
                first column (index 0) or the first header column.
        delimiter: CSV delimiter (default ',')
        has_header: whether the CSV has a header row

    Returns:
        dict with keys: count, mean, min, max, sum

    Raises:
        FileNotFoundError if file_path doesn't exist
        ValueError if column name not found or no numeric values
    """
    with open(file_path, 'r', newline='', encoding='utf-8') as f:
        reader = csv.reader(f, delimiter=delimiter)
        header = None
        try:
            first_row = next(reader)
        except StopIteration:
            raise ValueError('CSV is empty')

        # Determine column index
        if has_header:
            header = first_row
            if column is None:
                col_idx = 0
            elif isinstance(column, int):
                col_idx = column
            else:  # column is str
                if column in header:
                    col_idx = header.index(column)
                else:
                    raise ValueError(f"Column name '{column}' not found in header")
            rows_iter = reader
        else:
            if column is None:
                col_idx = 0
            elif isinstance(column, int):
                col_idx = column
            else:
                raise ValueError('CSV has no header; column must be an integer index')
            rows_iter = (r for r in (first_row, *reader))

        count = 0
        ssum = 0.0
        min_v = None
        max_v = None

        for row in rows_iter:
            if col_idx >= len(row):
                continue
            val = _to_float(row[col_idx])
            if val is None:
                continue
            count += 1
            ssum += val
            if min_v is None or val < min_v:
                min_v = val
            if max_v is None or val > max_v:
                max_v = val
        if count == 0:
            raise ValueError('No numeric values found in the chosen column')
        mean = ssum / count
        return {
            'count': count,
            'mean': mean,
            'min': min_v,
            'max': max_v,
            'sum': ssum,
        }

def main():
    # Create example CSV next to this script
    out_path = Path(__file__).parent / 'example_embedded.csv'
    csv_text = """value
1
2
3.5
4
NaN
-1
"""
    out_path.write_text(csv_text, encoding='utf-8')
    print(f'Wrote example CSV to: {out_path}')

    stats = read_csv_stats(str(out_path), column='value', has_header=True)
    print('\nComputed stats:')
    for k, v in stats.items():
        print(f'{k}: {v}')
if __name__ == '__main__':
    main()
