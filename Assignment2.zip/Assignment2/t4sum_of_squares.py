"""This module provides functions to calculate sum of squares using different approaches.
It demonstrates various Python features like list comprehension, reduce, and traditional loops."""
from functools import reduce
from typing import List, Union
def sum_of_squares_loop(numbers: List[Union[int, float]]) -> Union[int, float]:
    """Calculate sum of squares using a traditional for loop.
    Args:
        numbers: List of numbers (integers or floats)
    Returns:
        Sum of squares of the input numbers
    Example:
        sum_of_squares_loop([1, 2, 3]) -> 14  # (1² + 2² + 3²)"""
    total = 0
    for num in numbers:
        total += num * num
    return total
def sum_of_squares_comprehension(numbers: List[Union[int, float]]) -> Union[int, float]:
    """Calculate sum of squares using list comprehension.
    More Pythonic and often more readable approach.
    Args:
        numbers: List of numbers (integers or floats)
    Returns:
        Sum of squares of the input numbers"""
    return sum(num * num for num in numbers)
def sum_of_squares_reduce(numbers: List[Union[int, float]]) -> Union[int, float]:
    """Calculate sum of squares using reduce function.
    Demonstrates functional programming approach.
    Args:
        numbers: List of numbers (integers or floats)
    Returns:
        Sum of squares of the input numbers"""
    return reduce(lambda acc, num: acc + num * num, numbers, 0)
def sum_of_squares_range(n: int) -> int:
    """    Calculate sum of squares for range of numbers from 1 to n.
    Uses the mathematical formula: Σ(i²) = n(n+1)(2n+1)/6
    Args:
        n: Upper limit of range (inclusive)
    Returns:
        Sum of squares from 1² to n²
    Example:
        sum_of_squares_range(3) -> 14  # (1² + 2² + 3²)"""
    return (n * (n + 1) * (2 * n + 1)) // 6
# Demo and comparison of different approaches
if __name__ == "__main__":
    # Test cases
    test_lists = [
        [1, 2, 3],
        [1.5, 2.5, 3.5],
        range(1, 6),  # 1 to 5
        [-2, -1, 0, 1, 2]
    ]
    print("Sum of Squares Demo\n")
    # Test each list with different approaches
    for test_list in test_lists:
        print(f"Input numbers: {list(test_list)}")
        print(f"Using loop:         {sum_of_squares_loop(test_list)}")
        print(f"Using comprehension: {sum_of_squares_comprehension(test_list)}")
        print(f"Using reduce:        {sum_of_squares_reduce(test_list)}")
        print()
    # Demonstrate range formula
    n = 5
    print(f"Sum of squares from 1 to {n} using formula:")
    print(f"Result: {sum_of_squares_range(n)}")
    print(f"Verification using loop: {sum_of_squares_loop(range(1, n+1))}")