import requests
import json

def fetch_from_jsonplaceholder():
    """
    Fetches sample data from JSONPlaceholder API.
    JSONPlaceholder is a free online REST API for testing and prototyping.
    """
    print("=" * 60)
    print("Fetching Posts from JSONPlaceholder API")
    print("=" * 60)
    
    # API endpoint - fetches the first 3 posts
    url = "https://jsonplaceholder.typicode.com/posts?_limit=3"
    
    try:
        # Send GET request
        response = requests.get(url, timeout=10)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Parse JSON response
            data = response.json()
            
            # Display response in pretty JSON format
            print("\nResponse Status Code:", response.status_code)
            print("\nPretty JSON Response:\n")
            print(json.dumps(data, indent=2))
            
            return data
        else:
            print(f"Error: Failed to fetch data. Status code: {response.status_code}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Error: Failed to connect to API: {e}")
        print("\nNote: If you're experiencing network issues, here's what the API response would look like:")
        print_sample_jsonplaceholder_data()
        return None


def print_sample_jsonplaceholder_data():
    """
    Prints sample JSONPlaceholder data for demonstration purposes.
    """
    sample_data = [
        {
            "userId": 1,
            "id": 1,
            "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
            "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut et ipsa possimus iste sunt\nrepudiandae quia provident consequuntur asperiores expedita sint"
        },
        {
            "userId": 1,
            "id": 2,
            "title": "qui est esse",
            "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
        },
        {
            "userId": 1,
            "id": 3,
            "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
            "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestie porro eius odio et labore et velit aut"
        }
    ]
    print(json.dumps(sample_data, indent=2))


def fetch_from_openweathermap(city="London", api_key=None):
    """
    Fetches weather data from OpenWeatherMap API.
    Note: Requires a free API key from https://openweathermap.org/api
    For demo purposes, this shows the structure if you have an API key.
    """
    if not api_key:
        print("\n" + "=" * 60)
        print("OpenWeatherMap API (Requires API Key)")
        print("=" * 60)
        print("To use OpenWeatherMap:")
        print("1. Sign up at: https://openweathermap.org/api")
        print("2. Get a free API key")
        print("3. Replace 'YOUR_API_KEY' in the script")
        return None
    
    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": api_key,
        "units": "metric"
    }
    
    try:
        response = requests.get(url, params=params, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            print(f"\nWeather Data for {city}:\n")
            print(json.dumps(data, indent=2))
            return data
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Error: Failed to connect to API: {e}")
        return None


def main():
    print("\n🔗 Public API Connection Demo\n")
    
    # Example 1: JSONPlaceholder (No API key required)
    posts = fetch_from_jsonplaceholder()
    
    # Example 2: OpenWeatherMap (API key required - commented out)
    # Replace 'YOUR_API_KEY' with your actual API key
    # weather = fetch_from_openweathermap(city="New York", api_key="YOUR_API_KEY")
    
    fetch_from_openweathermap()
    
    print("\n" + "=" * 60)
    print("Demo Complete!")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
