import requests
import json
from datetime import datetime

def get_weather(city_name):
    api_key = "ba12414ecc2fbdd2d22d91fe289e19f6"   # Replace with your actual API key
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}&units=metric"

    try:
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            # Extract required fields
            weather_info = {
                "city": city_name,
                "temp": data["main"]["temp"],
                "humidity": data["main"]["humidity"],
                "weather": data["weather"][0]["description"].capitalize(),
                "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }

            # 1. Display JSON output in console
            print("\nWeather Details (JSON):")
            print(json.dumps(weather_info, indent=4))

            # 2. Append data to a local text file
            with open("results.txt", "a") as file:
                file.write(json.dumps(weather_info) + "\n")

        elif response.status_code == 404:
            print("\nError: City not found. Please enter a valid city.")

        elif response.status_code == 401:
            print("\nError: Invalid API key. Please check your API key.")

        else:
            print(f"\nError: Unable to fetch data. Status code: {response.status_code}")

    except requests.exceptions.RequestException as e:
        print(f"\nError: {e}")


# ----------- STATIC TEST CASES -----------

get_weather("London")
get_weather("New York")
get_weather("xyz123")   # Invalid city

# ----------- USER INPUT -----------

user_city = input("\nEnter a city name: ")
get_weather(user_city)
