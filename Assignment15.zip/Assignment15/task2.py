import requests
import json

def get_weather(city_name):
    api_key = "ba12414ecc2fbdd2d22d91fe289e19f6"   # Replace with your actual API key
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}&units=metric"

    try:
        response = requests.get(url)

        # If request is successful
        if response.status_code == 200:
            weather_data = response.json()
            print(f"\n✅ Weather details for: {city_name}")
            print(json.dumps(weather_data, indent=4))

        elif response.status_code == 401:
            print(f"\n❌ Error for {city_name}: Invalid API key.")

        elif response.status_code == 404:
            print(f"\n❌ Error for {city_name}: City not found.")

        else:
            print(f"\n⚠️ Error for {city_name}: Status code {response.status_code}")

    except requests.exceptions.ConnectionError:
        print(f"\n❌ Error for {city_name}: No internet connection.")

    except requests.exceptions.Timeout:
        print(f"\n❌ Error for {city_name}: Request timed out.")

    except requests.exceptions.RequestException as e:
        print(f"\n❌ Error for {city_name}: {e}")


# -------------- Test Cases --------------
test_cities = [
    "Hyderabad",     # valid
    "New York",      # valid
    "Delhi",         # valid
    "Hasanparthy",   # small town (may or may not be found)
    "InvalidCity123" # invalid
]

for city in test_cities:
    get_weather(city)
