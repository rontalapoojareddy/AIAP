# Task 1: Connect to a Public API

## Overview
This assignment demonstrates how to connect to public APIs and retrieve data using Python's `requests` library. The script includes working examples with proper error handling and formatted JSON output.

## What Was Implemented

### 1. **JSONPlaceholder API (No Auth Required)**
- **Purpose**: Demonstrates a simple GET request to a free REST API
- **Endpoint**: `https://jsonplaceholder.typicode.com/posts?_limit=3`
- **Features**:
  - Sends a GET request with a 10-second timeout
  - Parses JSON response
  - Displays data with pretty formatting (indented JSON)
  - Includes error handling for network issues

**Sample Output:**
```json
[
  {
    "userId": 1,
    "id": 1,
    "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
    "body": "quia et suscipit..."
  },
  {
    "userId": 1,
    "id": 2,
    "title": "qui est esse",
    "body": "est rerum tempore vitae..."
  },
  {
    "userId": 1,
    "id": 3,
    "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
    "body": "et iusto sed quo iure..."
  }
]
```

### 2. **OpenWeatherMap API (Optional - Requires API Key)**
- **Purpose**: Shows how to work with authenticated APIs
- **Setup Required**:
  1. Visit https://openweathermap.org/api
  2. Sign up for a free account
  3. Get your API key
  4. Replace `YOUR_API_KEY` in the script

**Example usage:**
```python
weather = fetch_from_openweathermap(city="New York", api_key="YOUR_API_KEY")
```

## Key Concepts Demonstrated

### 1. **GET Request**
```python
response = requests.get(url, timeout=10)
```
- Sends an HTTP GET request to the API endpoint
- `timeout` parameter prevents hanging indefinitely

### 2. **Status Code Checking**
```python
if response.status_code == 200:
    data = response.json()
```
- HTTP 200 = successful request
- Other status codes indicate errors (404, 500, etc.)

### 3. **JSON Parsing**
```python
data = response.json()  # Converts response to Python dict/list
```
- Parses JSON string into Python objects

### 4. **Pretty Printing**
```python
print(json.dumps(data, indent=2))
```
- `indent=2`: Adds 2-space indentation for readability
- Makes JSON output human-readable

### 5. **Error Handling**
```python
try:
    response = requests.get(url, timeout=10)
except requests.exceptions.RequestException as e:
    print(f"Error: {e}")
```
- Handles network errors gracefully
- Provides meaningful error messages

## How to Run

### Prerequisites
```bash
pip install requests
```

### Execute the Script
```bash
python api_connection.py
```

### Output
The script will:
1. Fetch 3 recent posts from JSONPlaceholder
2. Display the HTTP status code
3. Show the response in formatted JSON
4. Display information about OpenWeatherMap API setup

## Files Included

- **api_connection.py**: Main script with API connection examples
- **API_CONNECTION_GUIDE.md**: This documentation file

## Common Use Cases

### 1. Weather Application
```python
url = "https://api.openweathermap.org/data/2.5/weather"
params = {"q": "London", "appid": api_key, "units": "metric"}
response = requests.get(url, params=params)
```

### 2. User Data Retrieval
```python
url = "https://jsonplaceholder.typicode.com/users/1"
response = requests.get(url)
user = response.json()
```

### 3. With Custom Headers
```python
headers = {"Authorization": f"Bearer {token}"}
response = requests.get(url, headers=headers)
```

### 4. POST Request (Sending Data)
```python
data = {"title": "Test", "body": "Content"}
response = requests.post(url, json=data)
```

## Best Practices

✅ **Always use timeouts**
```python
response = requests.get(url, timeout=10)  # Good
```

✅ **Check status codes**
```python
if response.status_code == 200:
    # Process data
```

✅ **Handle exceptions**
```python
try:
    response = requests.get(url)
except requests.exceptions.RequestException as e:
    # Handle error
```

✅ **Use pretty printing for readability**
```python
print(json.dumps(data, indent=2))
```

❌ **Avoid infinite waits**
```python
response = requests.get(url)  # Bad - no timeout
```

❌ **Don't hardcode API keys**
```python
api_key = "YOUR_API_KEY"  # Bad practice
```

## Resources

- **Requests Documentation**: https://requests.readthedocs.io/
- **JSONPlaceholder**: https://jsonplaceholder.typicode.com/
- **OpenWeatherMap API**: https://openweathermap.org/api
- **JSON in Python**: https://docs.python.org/3/library/json.html

## Task Completion Checklist

✅ Connected to a public API (JSONPlaceholder)
✅ Sent a simple GET request
✅ Retrieved JSON response data
✅ Displayed response in readable format (pretty JSON)
✅ Included error handling
✅ Provided multiple API examples
✅ Added comprehensive documentation
