import requests

def get_weather(city_name):
    api_key = "ba12414ecc2fbdd2d22d91fe289e19f6"   # Replace with your actual API key
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={api_key}&units=metric"

    try:
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            temperature = data["main"]["temp"]
            humidity = data["main"]["humidity"]
            description = data["weather"][0]["description"]

            print("\n----------------------------")
            print(f"City: {city_name}")
            print(f"Temperature: {temperature}°C")
            print(f"Humidity: {humidity}%")
            print(f"Weather: {description.capitalize()}")
            print("----------------------------")

        elif response.status_code == 404:
            print("\nError: City not found. Please enter a valid city.")

        elif response.status_code == 401:
            print("\nError: Invalid API key. Please check your API key.")

        else:
            print(f"\nError: Unable to fetch data. Status code: {response.status_code}")

    except requests.exceptions.RequestException as e:
        print(f"\nError: {e}")


# ---------- STATIC TEST CASES ----------
print("Running Static Test Cases...")

get_weather("New York")    # Valid city
get_weather("xyz123")      # Invalid city


# ---------- USER INPUT ----------
print("\nNow try your own city name:")
user_city = input("Enter city name: ")
get_weather(user_city)
