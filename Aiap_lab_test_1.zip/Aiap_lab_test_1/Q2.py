from collections import deque
from typing import Deque, Generic, Iterable, List, Optional, TypeVar

T = TypeVar("T")


class Queue(Generic[T]):
    """
    A simple FIFO queue with enqueue, dequeue, and peek operations.
    Uses collections.deque for O(1) append/pop from both ends.
    """

    def __init__(self, initial: Optional[Iterable[T]] = None) -> None:
        self._data: Deque[T] = deque(initial or [])

    def enqueue(self, item: T) -> None:
        self._data.append(item)

    def dequeue(self) -> T:
        if not self._data:
            raise IndexError("Cannot dequeue from an empty queue.")
        return self._data.popleft()

    def peek(self) -> T:
        if not self._data:
            raise IndexError("Cannot peek into an empty queue.")
        return self._data[0]

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"Queue({list(self._data)!r})"


def test_basic_flow() -> List[str]:
    q: Queue[int] = Queue()
    log: List[str] = ["Created empty queue"]
    for value in (10, 20, 30):
        q.enqueue(value)
        log.append(f"Enqueued {value}, length now {len(q)}")

    log.append(f"Peek returned {q.peek()}")

    while len(q):
        removed = q.dequeue()
        log.append(f"Dequeued {removed}, length now {len(q)}")

    return log


def test_initial_values() -> List[str]:
    q: Queue[str] = Queue(["a", "b"])
    log = [f"Initialized with {q!r}"]
    q.enqueue("c")
    log.append(f"After enqueue 'c': {q!r}")
    log.append(f"Peek sees {q.peek()!r}")
    return log


def test_underflow() -> List[str]:
    q: Queue[int] = Queue()
    log = ["Testing underflow on empty queue"]
    try:
        q.dequeue()
    except IndexError as exc:
        log.append(f"Dequeue raised IndexError: {exc}")

    try:
        q.peek()
    except IndexError as exc:
        log.append(f"Peek raised IndexError: {exc}")

    return log


def read_positive_int(prompt: str) -> int:
    """
    Prompt the user until a positive integer (> 0) is entered.
    Keeps the interactive demo aligned with the positive-integer constraint.
    """
    while True:
        raw_value = input(prompt).strip()
        if not raw_value:
            print("Input cannot be empty.")
            continue
        if raw_value.isdigit():
            parsed = int(raw_value)
            if parsed > 0:
                return parsed
        print("Please enter a positive integer (greater than 0).")


def interactive_demo() -> List[str]:
    """
    Allow the user to enqueue, dequeue, and peek interactively.
    Logs every step so behavior can be reviewed later.
    """
    q: Queue[int] = Queue()
    log: List[str] = ["Interactive session started with an empty queue"]

    print(
        "\nInteractive Queue Demo:\n"
        "- Enter 'e' to enqueue a positive integer\n"
        "- Enter 'd' to dequeue\n"
        "- Enter 'p' to peek\n"
        "- Enter 'q' to quit the interactive session\n"
    )

    while True:
        action = input("Choose action (e/d/p/q): ").strip().lower()
        if action == "q":
            log.append("User exited the interactive session.")
            break
        if action == "e":
            value = read_positive_int("Enter a positive integer to enqueue: ")
            q.enqueue(value)
            state = f"Enqueued {value}; queue is now {q!r}"
            print(state)
            log.append(state)
            continue
        if action == "d":
            if len(q) == 0:
                message = "Cannot dequeue because the queue is empty."
                print(message)
                log.append(message)
            else:
                removed = q.dequeue()
                state = f"Dequeued {removed}; queue is now {q!r}"
                print(state)
                log.append(state)
            continue
        if action == "p":
            if len(q) == 0:
                message = "Cannot peek because the queue is empty."
                print(message)
                log.append(message)
            else:
                front = q.peek()
                state = f"Peek returned {front}; queue remains {q!r}"
                print(state)
                log.append(state)
            continue

        invalid = f"Ignored invalid action: {action!r}"
        print("Please enter one of e/d/p/q.")
        log.append(invalid)

    log.append(f"Final queue state: {q!r}")
    return log


def main() -> None:
    test_logs = {
        "basic_flow": test_basic_flow(),
        "initial_values": test_initial_values(),
        "underflow": test_underflow(),
    }

    for test_name, log in test_logs.items():
        print(f"\n[{test_name}]")
        for entry in log:
            print(f"- {entry}")

    interactive_log = interactive_demo()
    print("\n[interactive_demo]")
    for entry in interactive_log:
        print(f"- {entry}")

    print(
        "\nNotes: The AI-generated skeleton used deque for efficiency and explicit "
        "IndexError messages to handle empty queue edge cases. I expanded the tests "
        "to cover initialization, standard flow, underflow scenarios, and now a live "
        "user-input demo that enforces positive integers so edge handling is exercised "
        "instead of assumed."
    )


if __name__ == "__main__":
    main()

