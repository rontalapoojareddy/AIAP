from typing import List, Tuple


def validate_positive_integer(raw_value: str) -> Tuple[int, List[str]]:
    """
    Validate that the provided string represents a positive integer (> 0).
    Returns a tuple containing the parsed value and a log of validation steps.
    """
    log: List[str] = [f"Received input: {raw_value!r}"]
    raw_value = raw_value.strip()

    if not raw_value:
        log.append("Validation failed: empty input.")
        raise ValueError("\n".join(log))

    if not raw_value.isdigit():
        log.append("Validation failed: non-digit characters detected.")
        raise ValueError("\n".join(log))

    value = int(raw_value)
    if value <= 0:
        log.append("Validation failed: value must be greater than zero.")
        raise ValueError("\n".join(log))

    log.append(f"Validation passed: parsed value = {value}")
    return value, log


def generate_fibonacci(count: int) -> Tuple[List[int], List[str]]:
    """Generate the Fibonacci sequence up to 'count' terms and log each step."""
    if count == 1:
        return [0], ["Generated sequence with 1 term: [0]"]

    sequence = [0, 1]
    log = ["Initialized sequence: [0, 1]"]

    while len(sequence) < count:
        next_value = sequence[-1] + sequence[-2]
        sequence.append(next_value)
        log.append(f"Appended next term: {next_value}")

    log.append(f"Final sequence ({count} terms): {sequence}")
    return sequence, log


def main() -> None:
    user_input = input("Enter the number of Fibonacci terms (positive integer): ")
    try:
        count, validation_log = validate_positive_integer(user_input)
        sequence, generation_log = generate_fibonacci(count)
    except ValueError as exc:
        print("Input error:")
        print(exc)
        return

    print("Fibonacci sequence:")
    print(sequence)
    print("\nChange log:")
    for entry in validation_log + generation_log:
        print(f"- {entry}")


if __name__ == "__main__":
    main()

