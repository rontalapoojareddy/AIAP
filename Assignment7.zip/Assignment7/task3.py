# Debug the following code
def divide(a, b):
    return a / b

try:
    print(divide(10, 0))
except ZeroDivisionError:
    print("Error: Cannot divide by zero!")

